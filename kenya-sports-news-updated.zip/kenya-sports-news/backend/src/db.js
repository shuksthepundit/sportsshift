const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const DB_PATH = process.env.DB_PATH || "./data/news.db";
const resolvedPath = path.resolve(DB_PATH);
fs.mkdirSync(path.dirname(resolvedPath), { recursive: true });

const db = new Database(resolvedPath);
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    summary TEXT,
    url TEXT NOT NULL UNIQUE,
    source_name TEXT,
    country_code TEXT NOT NULL,
    sport TEXT NOT NULL,
    image_url TEXT,
    published_at TEXT,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_articles_country ON articles(country_code);
  CREATE INDEX IF NOT EXISTS idx_articles_sport ON articles(sport);
  CREATE INDEX IF NOT EXISTS idx_articles_published ON articles(published_at);

  CREATE TABLE IF NOT EXISTS videos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    video_url TEXT NOT NULL UNIQUE,
    thumbnail_url TEXT,
    channel_name TEXT,
    country_code TEXT,
    sport TEXT NOT NULL,
    published_at TEXT,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_videos_country ON videos(country_code);
  CREATE INDEX IF NOT EXISTS idx_videos_sport ON videos(sport);
  CREATE INDEX IF NOT EXISTS idx_videos_published ON videos(published_at);

  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    sport TEXT NOT NULL,
    venue_name TEXT,
    venue_city TEXT,
    country_code TEXT,
    event_date TEXT,
    sponsor_name TEXT,
    ticket_url TEXT NOT NULL UNIQUE,
    image_url TEXT,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_events_country ON events(country_code);
  CREATE INDEX IF NOT EXISTS idx_events_sport ON events(sport);
  CREATE INDEX IF NOT EXISTS idx_events_date ON events(event_date);
`);

module.exports = db;
