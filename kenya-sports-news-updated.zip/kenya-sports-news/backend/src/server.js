require("dotenv").config();
const express = require("express");
const cors = require("cors");
const cron = require("node-cron");
const newsRoutes = require("./routes/news");
const videoRoutes = require("./routes/videos");
const eventRoutes = require("./routes/events");
const { ingestAll } = require("./ingest");
const { ingestVideos } = require("./ingestVideos");
const { ingestEvents } = require("./ingestEvents");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => res.json({ ok: true }));
app.use("/api", newsRoutes);
app.use("/api", videoRoutes);
app.use("/api", eventRoutes);

async function ingestEverything() {
  const [articles, videos, events] = await Promise.all([
    ingestAll(),
    ingestVideos(),
    ingestEvents(),
  ]);
  return { articles, videos, events };
}

// Manual trigger, useful for a hosting provider's own scheduler (e.g. a Render/Railway
// cron job hitting this endpoint) instead of the in-process one below.
app.post("/api/ingest", async (_req, res) => {
  try {
    const results = await ingestEverything();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`API listening on http://localhost:${PORT}`);
});

// Built-in scheduler. Set INGEST_INTERVAL_MINUTES=0 to disable if you'd rather trigger
// POST /api/ingest from an external scheduler.
const intervalMinutes = Number(process.env.INGEST_INTERVAL_MINUTES ?? 30);
if (intervalMinutes > 0) {
  cron.schedule(`*/${intervalMinutes} * * * *`, () => {
    console.log("Running scheduled ingestion...");
    ingestEverything().catch((err) => console.error("Scheduled ingestion failed:", err));
  });
  // Also run once on boot so the app isn't empty on first start.
  ingestEverything().catch((err) => console.error("Initial ingestion failed:", err));
}
