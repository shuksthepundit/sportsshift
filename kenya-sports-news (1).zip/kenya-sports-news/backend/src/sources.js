// Feed sources to ingest, grouped by country.
//
// IMPORTANT: news sites change their RSS paths often (some drop RSS entirely when they
// redesign). Treat this list as a starting point, not a guarantee — before your first real
// ingest run, open each `feedUrl` in a browser and confirm it returns XML, not a 404/HTML
// page. Most WordPress-based sites (Capital FM, KBC, The Star) expose a feed at
// `<section-url>/feed/`. Sites built on custom CMSs (Nation.Africa, Standard) sometimes
// publish a dedicated RSS index instead — check standardmedia.co.ke/rssfeeds for the
// current list of Standard Group feeds.
//
// country_code follows ISO 3166-1 alpha-2. Add a new country by adding entries here —
// nothing else in the pipeline needs to change.

const SOURCES = [
  {
    countryCode: "KE",
    name: "Capital Sports",
    feedUrl: "https://www.capitalfm.co.ke/sports/feed/",
  },
  {
    countryCode: "KE",
    name: "The Star Kenya - Sports",
    feedUrl: "https://www.the-star.co.ke/sports/rss",
  },
  {
    countryCode: "KE",
    name: "KBC Sports",
    feedUrl: "https://www.kbc.co.ke/category/sports/feed/",
  },
  {
    countryCode: "KE",
    name: "Standard Sports",
    // Confirm the exact sports-section path at https://www.standardmedia.co.ke/rssfeeds
    feedUrl: "https://www.standardmedia.co.ke/rss/sports.php",
  },
];

const COUNTRIES = [
  { code: "KE", name: "Kenya", flag: "\uD83C\uDDF0\uD83C\uDDEA" },
  // Add more African countries here as you expand, e.g.:
  // { code: "NG", name: "Nigeria", flag: "\uD83C\uDDF3\uD83C\uDDEC" },
  // { code: "ZA", name: "South Africa", flag: "\uD83C\uDDFF\uD83C\uDDE6" },
];

const SPORTS = [
  "Football",
  "Athletics",
  "Rugby",
  "Volleyball",
  "Basketball",
  "Boxing",
  "Cricket",
  "Motorsport",
  "Golf",
  "Other",
];

module.exports = { SOURCES, COUNTRIES, SPORTS };
