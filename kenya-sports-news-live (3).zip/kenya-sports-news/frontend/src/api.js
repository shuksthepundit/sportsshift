const BASE = "/api";

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`Request to ${path} failed: ${res.status}`);
  return res.json();
}

export function fetchNews({ country, sport, limit = 30 } = {}) {
  const params = new URLSearchParams();
  if (country) params.set("country", country);
  if (sport) params.set("sport", sport);
  params.set("limit", String(limit));
  return get(`/news?${params.toString()}`);
}

export function fetchCountries() {
  return get("/countries");
}

export function fetchSports() {
  return get("/sports");
}

export function fetchLiveScores() {
  return get("/live-scores");
}

export function fetchResults() {
  return get("/results");
}

export function fetchDigest() {
  return get("/digest");
}

export function fetchDailyArticle() {
  return get("/daily-article");
}

export function fetchAutoArticles() {
  return get("/auto-articles");
}
