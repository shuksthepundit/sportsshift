import { useEffect, useState } from "react";
import { fetchAutoArticles } from "../api";

function ArticleRow({ article }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <li className="auto-article">
      <div className="auto-article__badge">
        {article.source_type === "result" ? "Match Report" : "News"}
      </div>
      <h4 className="auto-article__title">{article.title}</h4>
      {article.summary && <p className="auto-article__summary">{article.summary}</p>}

      {expanded && (
        <div className="auto-article__body">
          {article.body.split("\n\n").map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
      )}

      <button className="auto-article__toggle" onClick={() => setExpanded((e) => !e)}>
        {expanded ? "Show less" : "Read more"}
      </button>
    </li>
  );
}

export default function AutoArticlesSection() {
  const [articles, setArticles] = useState([]);
  const [status, setStatus] = useState("loading");

  useEffect(() => {
    fetchAutoArticles()
      .then((data) => {
        setArticles(data.articles);
        setStatus("ready");
      })
      .catch(() => setStatus("error"));
  }, []);

  if (status === "loading" || status === "error" || articles.length === 0) return null;

  return (
    <section className="auto-articles-section">
      <h3 className="auto-articles-section__title">Latest Auto-Generated Coverage</h3>
      <ul className="auto-articles-list">
        {articles.map((a) => (
          <ArticleRow key={a.id} article={a} />
        ))}
      </ul>
    </section>
  );
}
