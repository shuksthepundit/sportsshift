import LiveScoresWidget from "./LiveScoresWidget.jsx";
import DailyDigestWidget from "./DailyDigestWidget.jsx";
import FacebookWidget from "./FacebookWidget.jsx";

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <LiveScoresWidget />
      <DailyDigestWidget />
      <FacebookWidget />
    </aside>
  );
}
