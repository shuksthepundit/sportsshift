const FEATURES = [
  {
    label: "Sports News",
    desc: "Stay updated with the latest from across the continent.",
    icon: (
      <path d="M4 5h16v14H4z M4 9h16 M8 13h8 M8 16h5" fill="none" stroke="currentColor" strokeWidth="1.6" />
    ),
  },
  {
    label: "By country",
    desc: "Kenya first, more African markets rolling out next.",
    icon: (
      <path
        d="M12 3c4 4 4 10 0 18 -4-8-4-14 0-18Z M4 9h16 M4 15h16"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
      />
    ),
  },
  {
    label: "By sport code",
    desc: "Football, athletics, rugby and more, sorted for you.",
    icon: (
      <path
        d="M12 3l2.5 6.5H21l-5.5 4 2 6.5L12 16l-5.5 4 2-6.5L3 9.5h6.5Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    ),
  },
  {
    label: "Fresh, always",
    desc: "Pulled and tagged automatically as stories break.",
    icon: (
      <path
        d="M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3 M17 4v4h-4 M7 20v-4h4"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    ),
  },
];

export default function FeatureStrip() {
  return (
    <div className="feature-strip">
      {FEATURES.map((f) => (
        <div className="feature-box" key={f.label}>
          <svg viewBox="0 0 24 24" width="26" height="26" className="feature-icon" aria-hidden="true">
            {f.icon}
          </svg>
          <div className="feature-label">{f.label}</div>
          <div className="feature-desc">{f.desc}</div>
        </div>
      ))}
    </div>
  );
}
