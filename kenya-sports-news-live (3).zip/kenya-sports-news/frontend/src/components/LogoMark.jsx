export default function LogoMark({ size = 56 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 56 56"
      role="img"
      aria-label="Sports Shifts P&P logo"
    >
      <circle cx="28" cy="28" r="27" fill="#0d1b2e" stroke="#f4b400" strokeWidth="2" />
      <path
        d="M20 20c1-2 4-3 7-3 4 0 6 2 6 4 0 5-13 3-13 8 0 2 3 4 7 4 3 0 6-1 7-3"
        fill="none"
        stroke="#f4b400"
        strokeWidth="4"
        strokeLinecap="round"
      />
      <path d="M36 18l6-2-2 6" fill="none" stroke="#ffd447" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
