import { useEffect, useState } from "react";
import { fetchDailyArticle } from "../api";

export default function DailyArticleBanner() {
  const [article, setArticle] = useState(null);
  const [expanded, setExpanded] = useState(false);
  const [status, setStatus] = useState("loading");

  useEffect(() => {
    fetchDailyArticle()
      .then((data) => {
        setArticle(data);
        setStatus("ready");
      })
      .catch(() => setStatus("empty"));
  }, []);

  if (status === "loading" || status === "empty" || !article) return null;

  return (
    <section className="daily-article">
      <div className="daily-article__label">Daily Roundup — {article.published_date}</div>
      <h2 className="daily-article__title">{article.title}</h2>
      {article.summary && <p className="daily-article__summary">{article.summary}</p>}

      {expanded && (
        <div className="daily-article__body">
          {article.body.split("\n\n").map((paragraph, i) => (
            <p key={i}>{paragraph}</p>
          ))}
        </div>
      )}

      <button className="daily-article__toggle" onClick={() => setExpanded((e) => !e)}>
        {expanded ? "Show less" : "Read full roundup"}
      </button>
    </section>
  );
}
