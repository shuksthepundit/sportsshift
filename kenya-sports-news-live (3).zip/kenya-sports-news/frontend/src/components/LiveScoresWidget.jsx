import { useEffect, useState, useCallback } from "react";
import { fetchLiveScores, fetchResults } from "../api";

const REFRESH_MS = 12 * 60 * 60 * 1000; // 12 hours — matches the backend's live-score cadence

export default function LiveScoresWidget() {
  const [tab, setTab] = useState("live"); // "live" | "results"
  const [live, setLive] = useState([]);
  const [results, setResults] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ready | error
  const [lastUpdated, setLastUpdated] = useState(null);

  const load = useCallback(() => {
    Promise.all([fetchLiveScores(), fetchResults()])
      .then(([liveData, resultsData]) => {
        setLive(liveData.matches);
        setResults(resultsData.matches);
        setStatus("ready");
        setLastUpdated(new Date());
      })
      .catch(() => setStatus("error"));
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, REFRESH_MS);
    return () => clearInterval(id);
  }, [load]);

  const matches = tab === "live" ? live : results;

  return (
    <section className="sidebar-card">
      <div className="sidebar-card__header">
        <h3 className="sidebar-card__title">Scores</h3>
        {lastUpdated && (
          <span className="sidebar-card__updated">
            Updated {lastUpdated.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </span>
        )}
      </div>

      <div className="score-tabs">
        <button
          className={`score-tab ${tab === "live" ? "score-tab--active" : ""}`}
          onClick={() => setTab("live")}
        >
          <span className="live-dot" /> Live ({live.length})
        </button>
        <button
          className={`score-tab ${tab === "results" ? "score-tab--active" : ""}`}
          onClick={() => setTab("results")}
        >
          Results ({results.length})
        </button>
      </div>

      {status === "loading" && <p className="sidebar-card__status">Loading scores…</p>}
      {status === "error" && <p className="sidebar-card__status">Couldn't load scores.</p>}

      {status === "ready" && matches.length === 0 && (
        <p className="sidebar-card__status">
          {tab === "live" ? "No matches in play right now." : "No results in the last day."}
        </p>
      )}

      {status === "ready" && matches.length > 0 && (
        <ul className="match-list">
          {matches.map((m) => (
            <li key={m.id} className="match-row">
              <div className="match-row__competition">{m.competition || m.sport}</div>
              <div className="match-row__teams">
                <span>{m.home_team}</span>
                <span className="match-row__score">
                  {m.home_score ?? "-"} : {m.away_score ?? "-"}
                </span>
                <span>{m.away_team}</span>
              </div>
              <div className="match-row__meta">
                {tab === "live" ? (
                  <span className="match-row__minute">{m.match_minute || "LIVE"}</span>
                ) : (
                  <span>{m.match_date}</span>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
