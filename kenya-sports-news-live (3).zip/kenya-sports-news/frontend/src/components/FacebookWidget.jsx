import { useEffect } from "react";

const PAGE_URL = "https://www.facebook.com/Gameni90";

// Uses Facebook's own official Page Plugin (https://developers.facebook.com/docs/plugins/page-plugin/) —
// a public iframe embed Facebook provides for exactly this purpose. It renders and refreshes
// itself directly from Facebook; this component just loads Facebook's SDK once and mounts
// the required markup. There's no scraping and no login involved.
export default function FacebookWidget() {
  useEffect(() => {
    if (!document.getElementById("fb-root")) {
      const root = document.createElement("div");
      root.id = "fb-root";
      document.body.prepend(root);
    }

    if (window.FB) {
      window.FB.XFBML.parse();
      return;
    }

    if (document.getElementById("facebook-jssdk")) return;

    const script = document.createElement("script");
    script.id = "facebook-jssdk";
    script.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v19.0";
    script.async = true;
    script.defer = true;
    script.crossOrigin = "anonymous";
    document.body.appendChild(script);
  }, []);

  return (
    <section className="sidebar-card sidebar-card--facebook">
      <div className="sidebar-card__header">
        <h3 className="sidebar-card__title">On Facebook</h3>
      </div>
      <div
        className="fb-page"
        data-href={PAGE_URL}
        data-tabs="timeline"
        data-width="320"
        data-height="500"
        data-small-header="true"
        data-adapt-container-width="true"
        data-hide-cover="false"
        data-show-facepile="false"
      >
        <blockquote cite={PAGE_URL} className="fb-xfbml-parse-ignore">
          <a href={PAGE_URL}>Gameni90</a>
        </blockquote>
      </div>
    </section>
  );
}
