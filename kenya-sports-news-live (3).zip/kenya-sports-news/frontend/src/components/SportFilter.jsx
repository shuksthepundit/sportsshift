export default function SportFilter({ sports, activeSport, onSelect }) {
  return (
    <div className="sport-filter" role="tablist" aria-label="Filter by sport">
      <button
        className={`sport-pill ${!activeSport ? "is-active" : ""}`}
        onClick={() => onSelect(null)}
      >
        All codes
      </button>
      {sports
        .filter((s) => s.articleCount > 0)
        .map((s) => (
          <button
            key={s.name}
            className={`sport-pill ${activeSport === s.name ? "is-active" : ""}`}
            onClick={() => onSelect(s.name)}
          >
            {s.name}
            <span className="sport-count">{s.articleCount}</span>
          </button>
        ))}
    </div>
  );
}
