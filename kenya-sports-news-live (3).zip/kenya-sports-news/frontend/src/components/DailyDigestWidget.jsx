import { useEffect, useState, useCallback } from "react";
import { fetchDigest } from "../api";

// The underlying data only changes every ~12h server-side (see DAILY_DIGEST_INTERVAL_HOURS),
// but we poll at the same 15-min cadence as the rest of the sidebar for consistency —
// it's a cheap read from the local API either way, not a fresh AI search each time.
const REFRESH_MS = 15 * 60 * 1000;

export default function DailyDigestWidget() {
  const [items, setItems] = useState([]);
  const [status, setStatus] = useState("loading");

  const load = useCallback(() => {
    fetchDigest()
      .then((data) => {
        setItems(data.items);
        setStatus("ready");
      })
      .catch(() => setStatus("error"));
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, REFRESH_MS);
    return () => clearInterval(id);
  }, [load]);

  return (
    <section className="sidebar-card">
      <div className="sidebar-card__header">
        <h3 className="sidebar-card__title">Daily Digest</h3>
      </div>

      {status === "loading" && <p className="sidebar-card__status">Loading headlines…</p>}
      {status === "error" && <p className="sidebar-card__status">Couldn't load the digest.</p>}
      {status === "ready" && items.length === 0 && (
        <p className="sidebar-card__status">
          No headlines yet — run <code>npm run ingest:digest</code> in the backend.
        </p>
      )}

      {status === "ready" && items.length > 0 && (
        <ul className="digest-list">
          {items.map((item) => (
            <li key={item.id} className="digest-row">
              <a href={item.source_url} target="_blank" rel="noopener noreferrer">
                {item.headline}
              </a>
              {item.summary && <p className="digest-row__summary">{item.summary}</p>}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
