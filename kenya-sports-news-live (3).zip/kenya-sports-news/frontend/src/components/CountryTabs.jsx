export default function CountryTabs({ countries, activeCountry, onSelect }) {
  return (
    <nav className="country-tabs" aria-label="Filter by country">
      {countries.map((c) => (
        <button
          key={c.code}
          className={`country-tab ${activeCountry === c.code ? "is-active" : ""}`}
          onClick={() => onSelect(c.code)}
        >
          <span className="country-flag">{c.flag}</span>
          <span>{c.name}</span>
          <span className="country-count">{c.articleCount}</span>
        </button>
      ))}
    </nav>
  );
}
