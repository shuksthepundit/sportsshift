function timeAgo(isoString) {
  if (!isoString) return "";
  const diffMs = Date.now() - new Date(isoString).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

export default function NewsCard({ article }) {
  return (
    <a className="news-card" href={article.url} target="_blank" rel="noreferrer">
      {article.image_url ? (
        <div
          className="news-card-image"
          style={{ backgroundImage: `url(${article.image_url})` }}
        />
      ) : (
        <div className="news-card-image news-card-image--fallback">
          <span>{article.sport}</span>
        </div>
      )}
      <div className="news-card-body">
        <div className="news-card-meta">
          <span className="news-card-sport">{article.sport}</span>
          <span className="news-card-time">{timeAgo(article.published_at)}</span>
        </div>
        <h3 className="news-card-title">{article.title}</h3>
        {article.summary && <p className="news-card-summary">{article.summary}</p>}
        <div className="news-card-source">{article.source_name}</div>
      </div>
    </a>
  );
}
