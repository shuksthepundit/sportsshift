// Turns individual already-ingested items (a digest headline, or a finished match
// result) into their own standalone article — one article per item, not one combined
// roundup (see dailyArticleGenerator.js for the combined version). Like that module,
// this does NOT call web search itself: it synthesizes from facts already sitting in
// this app's own database, which keeps it cheap and avoids reproducing any external
// source's exact wording.

const Anthropic = require("@anthropic-ai/sdk");

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

async function callClaude(prompt, maxTokens = 900) {
  try {
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: maxTokens,
      messages: [{ role: "user", content: prompt }],
    });
    const text = response.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n")
      .trim();
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) return null;
    const parsed = JSON.parse(match[0]);
    if (!parsed.title || !parsed.body) return null;
    return parsed;
  } catch (err) {
    console.error("Auto article generation call failed:", err.message);
    return null;
  }
}

/**
 * Expand a daily_digest row into a standalone article.
 */
async function generateFromDigestItem(item) {
  const prompt = `You have this sports news item, already gathered from a web search:
Headline: ${item.headline}
Summary: ${item.summary || "(no summary)"}
Sport: ${item.sport || "unknown"}
Country: ${item.country_code || "unspecified"}

Write an ORIGINAL standalone article expanding on this, in your own words, 150-250 words. Add context and framing, but do NOT invent specific facts (scores, dates, names, quotes) beyond what's given above — if you don't have enough detail for a full article, write a shorter piece that stays strictly within the given facts rather than padding with invented specifics.

Return ONLY a JSON object, no prose, no markdown fences:
{
  "title": "Article headline, can refine the original",
  "summary": "One sentence standfirst, under 25 words",
  "body": "Full article body, plain text, \\n\\n between paragraphs"
}`;
  return callClaude(prompt);
}

/**
 * Turn a finished match (from live_matches) into a short match report.
 */
async function generateFromResult(match) {
  const prompt = `You have this match result, already gathered from a web search:
${match.home_team} ${match.home_score} - ${match.away_score} ${match.away_team}
Competition: ${match.competition || "unspecified"}
Sport: ${match.sport}
Date: ${match.match_date}

Write an ORIGINAL short match report, 100-180 words, in your own words. Do NOT invent details (goalscorers, incidents, quotes) that aren't given above — stick to what the scoreline and competition tell you, framed as a result report rather than a blow-by-blow account you can't actually support.

Return ONLY a JSON object, no prose, no markdown fences:
{
  "title": "Match report headline",
  "summary": "One sentence standfirst, under 25 words",
  "body": "Full report body, plain text, \\n\\n between paragraphs"
}`;
  return callClaude(prompt);
}

module.exports = { generateFromDigestItem, generateFromResult };
