const Anthropic = require("@anthropic-ai/sdk");
const { SPORTS, COUNTRIES } = require("./sources");

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SPORT_LIST = SPORTS.join(", ");
const COUNTRY_LIST = COUNTRIES.map((c) => `${c.code} (${c.name})`).join(", ");

/**
 * Classify a single article: which sport it's about, which country it's primarily about,
 * and a short neutral one-paragraph summary. Falls back to the feed's own country/"Other"
 * sport if the API call fails, so ingestion never blocks on a single bad classification.
 */
async function classifyArticle({ title, snippet, defaultCountryCode }) {
  const prompt = `You are tagging a sports news headline for a news app. Respond with ONLY a JSON object, no other text, no markdown fences.

Headline: ${title}
Snippet: ${snippet || "(none provided)"}

Return JSON with exactly these fields:
{
  "sport": one of [${SPORT_LIST}],
  "country_code": the ISO country code this article is mainly about, preferring one of [${COUNTRY_LIST}] when it applies, otherwise your best-guess ISO alpha-2 code,
  "summary": a neutral, one-sentence (under 30 words) summary in your own words
}`;

  try {
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 300,
      messages: [{ role: "user", content: prompt }],
    });

    const text = response.content
      .map((block) => (block.type === "text" ? block.text : ""))
      .join("")
      .trim()
      .replace(/^```json\s*|```$/g, "");

    const parsed = JSON.parse(text);
    return {
      sport: SPORTS.includes(parsed.sport) ? parsed.sport : "Other",
      countryCode: parsed.country_code || defaultCountryCode,
      summary: parsed.summary || null,
    };
  } catch (err) {
    console.error(`Classification failed for "${title}":`, err.message);
    return { sport: "Other", countryCode: defaultCountryCode, summary: null };
  }
}

module.exports = { classifyArticle };
