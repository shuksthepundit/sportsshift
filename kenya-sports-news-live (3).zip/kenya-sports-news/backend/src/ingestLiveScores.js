require("dotenv").config();
const db = require("./db");
const { fetchLiveAndResults } = require("./liveScoresSearch");

const deleteLiveStmt = db.prepare(`DELETE FROM live_matches WHERE status = 'live'`);

const upsertStmt = db.prepare(`
  INSERT INTO live_matches
    (sport, competition, home_team, away_team, home_score, away_score, status, match_minute, match_date, source, updated_at)
  VALUES
    (@sport, @competition, @home_team, @away_team, @home_score, @away_score, @status, @match_minute, @match_date, @source, datetime('now'))
  ON CONFLICT(home_team, away_team, match_date, sport) DO UPDATE SET
    home_score = excluded.home_score,
    away_score = excluded.away_score,
    status = excluded.status,
    match_minute = excluded.match_minute,
    updated_at = datetime('now')
`);

// Safety net beyond the prompt's own instructions: results older than 1 day never
// linger in the table even if something upstream misbehaves.
const pruneOldResultsStmt = db.prepare(`
  DELETE FROM live_matches WHERE status = 'finished' AND match_date < date('now', '-1 day')
`);

async function ingestLiveScores() {
  console.log("Starting live scores ingestion run...");
  const { live, results } = await fetchLiveAndResults();

  // Live matches are a snapshot — replace the whole set rather than merging, so a
  // match that has since ended (and wasn't returned this run) disappears from "live".
  deleteLiveStmt.run();

  let liveAdded = 0;
  for (const match of live) {
    if (!match.homeTeam || !match.awayTeam) continue;
    upsertStmt.run({
      sport: match.sport || "Other",
      competition: match.competition || null,
      home_team: match.homeTeam,
      away_team: match.awayTeam,
      home_score: match.homeScore ?? null,
      away_score: match.awayScore ?? null,
      status: "live",
      match_minute: match.minute || null,
      match_date: match.matchDate || new Date().toISOString().slice(0, 10),
      source: "AI search (flashscore + web)",
    });
    liveAdded++;
  }

  let resultsAdded = 0;
  for (const match of results) {
    if (!match.homeTeam || !match.awayTeam || !match.matchDate) continue;
    upsertStmt.run({
      sport: match.sport || "Other",
      competition: match.competition || null,
      home_team: match.homeTeam,
      away_team: match.awayTeam,
      home_score: match.homeScore ?? null,
      away_score: match.awayScore ?? null,
      status: "finished",
      match_minute: null,
      match_date: match.matchDate,
      source: "AI search (flashscore + web)",
    });
    resultsAdded++;
  }

  pruneOldResultsStmt.run();

  console.log(`Live scores ingestion complete. ${liveAdded} live match(es), ${resultsAdded} recent result(s).`);
  return { liveAdded, resultsAdded };
}

if (require.main === module) {
  ingestLiveScores()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Live scores ingestion run failed:", err);
      process.exit(1);
    });
}

module.exports = { ingestLiveScores };
