// Generates one AI-written daily roundup article from data already sitting in this
// app's own database (recent articles, results, videos, events, digest items) — it does
// NOT call web search itself, since the underlying facts were already gathered (and
// already paraphrased into our own words) by the other ingestion jobs. This keeps the
// daily article cheap (one plain Claude call, no search cost) and copyright-safe (Claude
// is asked to synthesize from a facts list, not to rewrite any single source's prose).

const Anthropic = require("@anthropic-ai/sdk");
const db = require("./db");

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

function gatherFacts() {
  const results = db
    .prepare(
      `SELECT sport, competition, home_team, away_team, home_score, away_score, match_date
       FROM live_matches WHERE status = 'finished' AND match_date >= date('now', '-1 day')
       ORDER BY match_date DESC LIMIT 15`
    )
    .all();

  const headlines = db
    .prepare(
      `SELECT headline, summary, sport, country_code FROM daily_digest
       ORDER BY ingested_at DESC LIMIT 15`
    )
    .all();

  const articles = db
    .prepare(
      `SELECT title, summary, sport, country_code FROM articles
       ORDER BY COALESCE(published_at, ingested_at) DESC LIMIT 15`
    )
    .all();

  const events = db
    .prepare(
      `SELECT name, sport, venue_name, venue_city, country_code, event_date, sponsor_name
       FROM events WHERE event_date >= date('now') ORDER BY event_date ASC LIMIT 10`
    )
    .all();

  return { results, headlines, articles, events };
}

function buildPrompt(facts) {
  return `You are writing today's sports roundup for an African sports news site (Kenya-first, pan-African, with global coverage). Below are facts gathered from today's data — recent match results, headlines, news article summaries, and upcoming events. Some entries may be empty; work with what's there, and if everything is empty, write a short general piece noting it's a quiet news day rather than inventing facts.

RESULTS (last day):
${JSON.stringify(facts.results, null, 2)}

DIGEST HEADLINES:
${JSON.stringify(facts.headlines, null, 2)}

RECENT ARTICLE SUMMARIES:
${JSON.stringify(facts.articles, null, 2)}

UPCOMING EVENTS:
${JSON.stringify(facts.events, null, 2)}

Write an ORIGINAL roundup article, entirely in your own words — do not copy phrasing from the facts above, synthesize and contextualize instead. Never state a specific fact (score, date, name) that isn't present in the data above.

Return ONLY a JSON object, no prose, no markdown fences, in exactly this shape:
{
  "title": "A single punchy headline for today's roundup",
  "summary": "One-sentence standfirst, under 25 words",
  "body": "The full article body, 3-5 short paragraphs, plain text with \\n\\n between paragraphs"
}`;
}

/**
 * Generate today's roundup article. Returns { title, summary, body } or null on failure.
 */
async function generateDailyArticle() {
  const facts = gatherFacts();

  try {
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 1500,
      messages: [{ role: "user", content: buildPrompt(facts) }],
    });

    const text = response.content
      .filter((block) => block.type === "text")
      .map((block) => block.text)
      .join("\n")
      .trim();

    const match = text.match(/\{[\s\S]*\}/);
    if (!match) {
      console.error("Daily article generation returned no parseable JSON:", text.slice(0, 300));
      return null;
    }

    const parsed = JSON.parse(match[0]);
    if (!parsed.title || !parsed.body) return null;
    return parsed;
  } catch (err) {
    console.error("Daily article generation failed:", err.message);
    return null;
  }
}

module.exports = { generateDailyArticle };
