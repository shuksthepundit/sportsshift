// Shared helper: ask Claude to search the web and return a strict JSON answer.
// This is how "Flashscore updates" and "daily sports news" are sourced in this app —
// there's no Flashscore API and scraping flashscore.com directly would violate its terms
// of service, so instead we let Claude's built-in web search tool look across
// flashscore.com, other reliable score sites, and sports news outlets, then have it
// hand back structured facts (team names, scores, headlines) rather than us scraping
// any single site ourselves.
//
// Cost note: every call here is a real Anthropic API call that performs live web
// searches, which has a per-search cost on top of normal token usage. Running this
// every 15 minutes (as ingestLiveScores.js does) is roughly 96 calls/day — check your
// Anthropic usage/billing if you're on a tight budget, and raise LIVE_SCORES_INTERVAL_MINUTES
// in .env if you want to reduce that.

const Anthropic = require("@anthropic-ai/sdk");

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

/**
 * Run a web-search-augmented prompt and parse the model's final answer as JSON.
 * Returns the parsed value, or `null` if the call/parse fails (callers should treat
 * `null` as "skip this run" rather than crashing the ingestion job).
 */
async function searchForJSON(prompt, { maxTokens = 2000 } = {}) {
  try {
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: maxTokens,
      tools: [{ type: "web_search_20250305", name: "web_search" }],
      messages: [{ role: "user", content: prompt }],
    });

    const text = response.content
      .filter((block) => block.type === "text")
      .map((block) => block.text)
      .join("\n")
      .trim();

    // The model may wrap JSON in prose or fences despite instructions — pull out the
    // first {...} or [...] block rather than assuming the whole text is clean JSON.
    const match = text.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (!match) {
      console.error("AI search returned no parseable JSON:", text.slice(0, 300));
      return null;
    }

    return JSON.parse(match[0]);
  } catch (err) {
    console.error("AI web search call failed:", err.message);
    return null;
  }
}

module.exports = { searchForJSON };
