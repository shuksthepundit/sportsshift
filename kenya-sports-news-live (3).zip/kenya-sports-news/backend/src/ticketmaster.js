// Thin wrapper around the official Ticketmaster Discovery API for sports events.
// Docs: https://developer.ticketmaster.com/products-and-docs/apis/discovery-api/v2/
//
// Requires TICKETMASTER_API_KEY in .env — free to get at
// https://developer.ticketmaster.com/ (self-serve, instant approval for the "Discovery" API).
//
// Coverage note: Ticketmaster's inventory is strongest in North America and Europe.
// For some African countries it may return 0 events — that's expected, not a bug; treat
// this source as a supplement to the RSS feeds, not the primary source for those countries.

const TICKETMASTER_URL = "https://app.ticketmaster.com/discovery/v2/events.json";

/**
 * Fetch upcoming sports events for a given ISO country code.
 * Returns an array of normalized event objects, or [] on failure/no results.
 */
async function fetchSportsEvents(countryCode, { size = 20 } = {}) {
  const apiKey = process.env.TICKETMASTER_API_KEY;
  if (!apiKey) {
    console.warn("TICKETMASTER_API_KEY not set — skipping event ingestion for:", countryCode);
    return [];
  }

  const params = new URLSearchParams({
    apikey: apiKey,
    countryCode,
    classificationName: "Sports",
    size: String(size),
    sort: "date,asc",
  });

  try {
    const res = await fetch(`${TICKETMASTER_URL}?${params.toString()}`);
    if (!res.ok) {
      const body = await res.text();
      console.error(`Ticketmaster fetch failed (${res.status}) for ${countryCode}:`, body.slice(0, 300));
      return [];
    }
    const data = await res.json();
    const events = data._embedded?.events || [];

    return events.map((event) => {
      const venue = event._embedded?.venues?.[0];
      const classification = event.classifications?.[0];
      const sponsor = event.promoter?.name || event.promoters?.[0]?.name || null;

      return {
        name: event.name,
        sport: classification?.genre?.name || classification?.segment?.name || "Other",
        venueName: venue?.name || null,
        venueCity: venue?.city?.name || null,
        countryCode: venue?.country?.countryCode || countryCode,
        eventDate: event.dates?.start?.dateTime || event.dates?.start?.localDate || null,
        sponsorName: sponsor,
        ticketUrl: event.url,
        imageUrl: event.images?.[0]?.url || null,
      };
    });
  } catch (err) {
    console.error(`Ticketmaster fetch error for ${countryCode}:`, err.message);
    return [];
  }
}

module.exports = { fetchSportsEvents };
