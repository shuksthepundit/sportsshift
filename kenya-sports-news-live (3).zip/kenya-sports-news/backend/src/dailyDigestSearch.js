const { searchForJSON } = require("./aiSearch");

const DAILY_DIGEST_PROMPT = `Search the web for today's most notable sports news headlines, with priority on Kenya and Africa but including major global sports stories too — cover match previews/recaps, major highlights, awards, and sponsorship news.

Return ONLY a JSON array, no prose, no markdown fences, of up to 12 items in exactly this shape:
[
  {
    "headline": "Short headline in your own words",
    "summary": "One sentence of context, under 30 words, in your own words — never copy text verbatim from a source",
    "sport": "Football",
    "country": "KE",
    "url": "https://source-article-url.example.com"
  }
]

Rules:
- headline and summary must be original phrasing, not copied sentences from any source.
- country should be an ISO alpha-2 code when the story is about a specific country, or omit the field for global stories.
- url must be a real URL you found via search — never invent one.
- Only include stories from roughly the last 24 hours.`;

async function fetchDailyDigest() {
  const data = await searchForJSON(DAILY_DIGEST_PROMPT, { maxTokens: 3000 });
  return Array.isArray(data) ? data : [];
}

module.exports = { fetchDailyDigest };
