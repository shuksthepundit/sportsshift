const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const DB_PATH = process.env.DB_PATH || "./data/news.db";
const resolvedPath = path.resolve(DB_PATH);
fs.mkdirSync(path.dirname(resolvedPath), { recursive: true });

const db = new Database(resolvedPath);
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    summary TEXT,
    url TEXT NOT NULL UNIQUE,
    source_name TEXT,
    country_code TEXT NOT NULL,
    sport TEXT NOT NULL,
    image_url TEXT,
    published_at TEXT,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_articles_country ON articles(country_code);
  CREATE INDEX IF NOT EXISTS idx_articles_sport ON articles(sport);
  CREATE INDEX IF NOT EXISTS idx_articles_published ON articles(published_at);

  CREATE TABLE IF NOT EXISTS videos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    video_url TEXT NOT NULL UNIQUE,
    thumbnail_url TEXT,
    channel_name TEXT,
    country_code TEXT,
    sport TEXT NOT NULL,
    published_at TEXT,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_videos_country ON videos(country_code);
  CREATE INDEX IF NOT EXISTS idx_videos_sport ON videos(sport);
  CREATE INDEX IF NOT EXISTS idx_videos_published ON videos(published_at);

  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    sport TEXT NOT NULL,
    venue_name TEXT,
    venue_city TEXT,
    country_code TEXT,
    event_date TEXT,
    sponsor_name TEXT,
    ticket_url TEXT NOT NULL UNIQUE,
    image_url TEXT,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_events_country ON events(country_code);
  CREATE INDEX IF NOT EXISTS idx_events_sport ON events(sport);
  CREATE INDEX IF NOT EXISTS idx_events_date ON events(event_date);

  -- 'live' rows are wiped and replaced wholesale on every ingest run (see
  -- ingestLiveScores.js) since an in-play score is only ever a snapshot.
  -- 'finished' rows are upserted keyed on the unique index below and pruned to the
  -- last day, so this table only ever holds matches in play right now or results
  -- from today/yesterday — never older results, never fixtures that haven't started.
  CREATE TABLE IF NOT EXISTS live_matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sport TEXT NOT NULL,
    competition TEXT,
    home_team TEXT NOT NULL,
    away_team TEXT NOT NULL,
    home_score TEXT,
    away_score TEXT,
    status TEXT NOT NULL, -- 'live' | 'finished'
    match_minute TEXT,
    match_date TEXT,
    source TEXT,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE UNIQUE INDEX IF NOT EXISTS idx_live_matches_unique
    ON live_matches(home_team, away_team, match_date, sport);
  CREATE INDEX IF NOT EXISTS idx_live_matches_status ON live_matches(status);
  CREATE INDEX IF NOT EXISTS idx_live_matches_date ON live_matches(match_date);

  CREATE TABLE IF NOT EXISTS daily_digest (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    headline TEXT NOT NULL,
    summary TEXT,
    sport TEXT,
    country_code TEXT,
    source_url TEXT UNIQUE,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_daily_digest_ingested ON daily_digest(ingested_at);

  -- One row per calendar day (published_date is UNIQUE), holding a full AI-written
  -- roundup article synthesized from what's already in the other tables that day.
  CREATE TABLE IF NOT EXISTS daily_articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    summary TEXT,
    published_date TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_daily_articles_date ON daily_articles(published_date);

  -- One row per SOURCE ITEM (a digest headline or a finished match), not per day —
  -- unlike daily_articles above. source_ref is a stable key for the originating item
  -- (the headline's URL, or a team/date/sport key for a match) so the same item never
  -- gets turned into a duplicate article across ingestion runs.
  CREATE TABLE IF NOT EXISTS auto_articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_type TEXT NOT NULL, -- 'digest' | 'result'
    source_ref TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    summary TEXT,
    sport TEXT,
    country_code TEXT,
    published_date TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE UNIQUE INDEX IF NOT EXISTS idx_auto_articles_source ON auto_articles(source_type, source_ref);
  CREATE INDEX IF NOT EXISTS idx_auto_articles_date ON auto_articles(published_date);
`);

module.exports = db;
