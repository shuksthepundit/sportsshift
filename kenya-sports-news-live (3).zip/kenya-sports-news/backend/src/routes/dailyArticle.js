const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/daily-article — today's (or most recent) roundup article.
router.get("/daily-article", (_req, res) => {
  const row = db
    .prepare(
      `SELECT id, title, body, summary, published_date, created_at
       FROM daily_articles
       ORDER BY published_date DESC
       LIMIT 1`
    )
    .get();

  if (!row) {
    return res.status(404).json({ error: "No daily article published yet." });
  }
  res.json(row);
});

// GET /api/daily-articles — recent archive, newest first.
router.get("/daily-articles", (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 14, 60);
  const rows = db
    .prepare(
      `SELECT id, title, summary, published_date FROM daily_articles
       ORDER BY published_date DESC LIMIT ?`
    )
    .all(limit);
  res.json({ articles: rows, count: rows.length });
});

module.exports = router;
