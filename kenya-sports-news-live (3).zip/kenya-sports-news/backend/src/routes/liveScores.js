const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/live-scores — matches actually in play right now, nothing else.
router.get("/live-scores", (_req, res) => {
  const rows = db
    .prepare(
      `SELECT id, sport, competition, home_team, away_team, home_score, away_score, match_minute, match_date, updated_at
       FROM live_matches
       WHERE status = 'live'
       ORDER BY updated_at DESC`
    )
    .all();
  res.json({ matches: rows, count: rows.length });
});

// GET /api/results — finished matches from today or yesterday only (enforced again
// here as a safety net, on top of what ingestLiveScores.js already prunes).
router.get("/results", (_req, res) => {
  const rows = db
    .prepare(
      `SELECT id, sport, competition, home_team, away_team, home_score, away_score, match_date, updated_at
       FROM live_matches
       WHERE status = 'finished' AND match_date >= date('now', '-1 day')
       ORDER BY match_date DESC, updated_at DESC`
    )
    .all();
  res.json({ matches: rows, count: rows.length });
});

module.exports = router;
