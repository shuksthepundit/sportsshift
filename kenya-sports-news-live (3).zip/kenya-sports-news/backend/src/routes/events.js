const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/events?country=KE&sport=Athletics&upcoming=true&limit=30&offset=0
router.get("/events", (req, res) => {
  const { country, sport, upcoming, limit = 30, offset = 0 } = req.query;

  const conditions = [];
  const params = {};

  if (country) {
    conditions.push("country_code = @country");
    params.country = country;
  }
  if (sport) {
    conditions.push("sport = @sport");
    params.sport = sport;
  }
  if (upcoming === "true") {
    conditions.push("event_date >= datetime('now')");
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  params.limit = Math.min(Number(limit) || 30, 100);
  params.offset = Number(offset) || 0;

  const rows = db
    .prepare(
      `SELECT id, name, sport, venue_name, venue_city, country_code, event_date, sponsor_name, ticket_url, image_url
       FROM events
       ${where}
       ORDER BY event_date ASC
       LIMIT @limit OFFSET @offset`
    )
    .all(params);

  res.json({ events: rows, count: rows.length });
});

module.exports = router;
