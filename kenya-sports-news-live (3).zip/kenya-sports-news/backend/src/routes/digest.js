const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/digest — AI-search-sourced daily sports headlines for the sidebar.
router.get("/digest", (_req, res) => {
  const rows = db
    .prepare(
      `SELECT id, headline, summary, sport, country_code, source_url, ingested_at
       FROM daily_digest
       ORDER BY ingested_at DESC
       LIMIT 20`
    )
    .all();
  res.json({ items: rows, count: rows.length });
});

module.exports = router;
