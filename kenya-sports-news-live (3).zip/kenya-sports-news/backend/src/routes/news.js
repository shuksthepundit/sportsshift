const express = require("express");
const db = require("../db");
const { COUNTRIES, SPORTS } = require("../sources");

const router = express.Router();

// GET /api/news?country=KE&sport=Athletics&limit=30&offset=0
router.get("/news", (req, res) => {
  const { country, sport, limit = 30, offset = 0 } = req.query;

  const conditions = [];
  const params = {};

  if (country) {
    conditions.push("country_code = @country");
    params.country = country;
  }
  if (sport) {
    conditions.push("sport = @sport");
    params.sport = sport;
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  params.limit = Math.min(Number(limit) || 30, 100);
  params.offset = Number(offset) || 0;

  const rows = db
    .prepare(
      `SELECT id, title, summary, url, source_name, country_code, sport, image_url, published_at
       FROM articles
       ${where}
       ORDER BY COALESCE(published_at, ingested_at) DESC
       LIMIT @limit OFFSET @offset`
    )
    .all(params);

  res.json({ articles: rows, count: rows.length });
});

// GET /api/countries — which countries are configured (and how many articles each has)
router.get("/countries", (_req, res) => {
  const counts = db
    .prepare(`SELECT country_code, COUNT(*) as count FROM articles GROUP BY country_code`)
    .all();
  const countMap = Object.fromEntries(counts.map((c) => [c.country_code, c.count]));

  res.json(
    COUNTRIES.map((c) => ({ ...c, articleCount: countMap[c.code] || 0 }))
  );
});

// GET /api/sports — which sport categories exist (and how many articles each has)
router.get("/sports", (_req, res) => {
  const counts = db
    .prepare(`SELECT sport, COUNT(*) as count FROM articles GROUP BY sport`)
    .all();
  const countMap = Object.fromEntries(counts.map((s) => [s.sport, s.count]));

  res.json(SPORTS.map((s) => ({ name: s, articleCount: countMap[s] || 0 })));
});

module.exports = router;
