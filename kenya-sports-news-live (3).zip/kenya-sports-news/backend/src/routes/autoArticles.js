const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/auto-articles?source=digest|result&limit=20
router.get("/auto-articles", (req, res) => {
  const { source, limit = 20 } = req.query;

  const conditions = [];
  const params = {};
  if (source) {
    conditions.push("source_type = @source");
    params.source = source;
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  params.limit = Math.min(Number(limit) || 20, 60);

  const rows = db
    .prepare(
      `SELECT id, source_type, title, body, summary, sport, country_code, published_date, created_at
       FROM auto_articles
       ${where}
       ORDER BY created_at DESC
       LIMIT @limit`
    )
    .all(params);

  res.json({ articles: rows, count: rows.length });
});

module.exports = router;
