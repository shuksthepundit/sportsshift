const express = require("express");
const db = require("../db");

const router = express.Router();

// GET /api/videos?country=KE&sport=Athletics&limit=30&offset=0
router.get("/videos", (req, res) => {
  const { country, sport, limit = 30, offset = 0 } = req.query;

  const conditions = [];
  const params = {};

  if (country) {
    conditions.push("country_code = @country");
    params.country = country;
  }
  if (sport) {
    conditions.push("sport = @sport");
    params.sport = sport;
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  params.limit = Math.min(Number(limit) || 30, 100);
  params.offset = Number(offset) || 0;

  const rows = db
    .prepare(
      `SELECT id, title, description, video_url, thumbnail_url, channel_name, country_code, sport, published_at
       FROM videos
       ${where}
       ORDER BY COALESCE(published_at, ingested_at) DESC
       LIMIT @limit OFFSET @offset`
    )
    .all(params);

  res.json({ videos: rows, count: rows.length });
});

module.exports = router;
