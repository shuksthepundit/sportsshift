// Thin wrapper around the official YouTube Data API v3 search endpoint.
// Docs: https://developers.google.com/youtube/v3/docs/search/list
//
// Requires YOUTUBE_API_KEY in .env — get a free key (with daily quota) from
// https://console.cloud.google.com/apis/credentials after enabling "YouTube Data API v3"
// on a project.

const YOUTUBE_SEARCH_URL = "https://www.googleapis.com/youtube/v3/search";

/**
 * Search YouTube for recent sports videos matching a query.
 * Returns an array of { title, description, videoUrl, thumbnailUrl, channelName, publishedAt }
 * or an empty array on failure (never throws — a bad/missing key shouldn't crash ingestion).
 */
async function searchSportsVideos(query, { maxResults = 5, publishedAfter } = {}) {
  const apiKey = process.env.YOUTUBE_API_KEY;
  if (!apiKey) {
    console.warn("YOUTUBE_API_KEY not set — skipping YouTube ingestion for:", query);
    return [];
  }

  const params = new URLSearchParams({
    part: "snippet",
    q: query,
    type: "video",
    order: "date",
    maxResults: String(maxResults),
    key: apiKey,
  });

  // Default: only videos from the last 24 hours, matching the "daily" brief.
  const after = publishedAfter || new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  params.set("publishedAfter", after);

  try {
    const res = await fetch(`${YOUTUBE_SEARCH_URL}?${params.toString()}`);
    if (!res.ok) {
      const body = await res.text();
      console.error(`YouTube search failed (${res.status}) for "${query}":`, body.slice(0, 300));
      return [];
    }
    const data = await res.json();
    return (data.items || [])
      .filter((item) => item.id && item.id.videoId)
      .map((item) => ({
        title: item.snippet.title,
        description: item.snippet.description,
        videoUrl: `https://www.youtube.com/watch?v=${item.id.videoId}`,
        thumbnailUrl: item.snippet.thumbnails?.medium?.url || item.snippet.thumbnails?.default?.url,
        channelName: item.snippet.channelTitle,
        publishedAt: item.snippet.publishedAt,
      }));
  } catch (err) {
    console.error(`YouTube search error for "${query}":`, err.message);
    return [];
  }
}

module.exports = { searchSportsVideos };
