require("dotenv").config();
const db = require("./db");
const { generateFromDigestItem, generateFromResult } = require("./autoArticleGenerator");

// Bound how many articles get generated per run — each one is a real API call, and
// there's no reason to generate hundreds at once even if the backlog is large.
const MAX_PER_SOURCE_PER_RUN = Number(process.env.AUTO_ARTICLES_MAX_PER_RUN ?? 5);

const insertStmt = db.prepare(`
  INSERT OR IGNORE INTO auto_articles
    (source_type, source_ref, title, body, summary, sport, country_code, published_date)
  VALUES
    (@source_type, @source_ref, @title, @body, @summary, @sport, @country_code, @published_date)
`);

function alreadyConverted(sourceType, sourceRef) {
  return !!db
    .prepare(`SELECT 1 FROM auto_articles WHERE source_type = ? AND source_ref = ?`)
    .get(sourceType, sourceRef);
}

async function processDigestItems() {
  const items = db
    .prepare(`SELECT * FROM daily_digest ORDER BY ingested_at DESC LIMIT 50`)
    .all()
    .filter((item) => !alreadyConverted("digest", item.source_url))
    .slice(0, MAX_PER_SOURCE_PER_RUN);

  let added = 0;
  for (const item of items) {
    const article = await generateFromDigestItem(item);
    if (!article) continue;
    insertStmt.run({
      source_type: "digest",
      source_ref: item.source_url,
      title: article.title,
      body: article.body,
      summary: article.summary || null,
      sport: item.sport || null,
      country_code: item.country_code || null,
      published_date: new Date().toISOString().slice(0, 10),
    });
    added++;
  }
  return added;
}

async function processResults() {
  const matches = db
    .prepare(
      `SELECT * FROM live_matches WHERE status = 'finished' AND match_date >= date('now', '-1 day')
       ORDER BY match_date DESC LIMIT 50`
    )
    .all()
    .filter((m) => !alreadyConverted("result", `${m.home_team}|${m.away_team}|${m.match_date}|${m.sport}`))
    .slice(0, MAX_PER_SOURCE_PER_RUN);

  let added = 0;
  for (const match of matches) {
    const article = await generateFromResult(match);
    if (!article) continue;
    insertStmt.run({
      source_type: "result",
      source_ref: `${match.home_team}|${match.away_team}|${match.match_date}|${match.sport}`,
      title: article.title,
      body: article.body,
      summary: article.summary || null,
      sport: match.sport,
      country_code: null,
      published_date: match.match_date,
    });
    added++;
  }
  return added;
}

async function ingestAutoArticles() {
  console.log("Starting auto article generation run...");
  const [fromDigest, fromResults] = await Promise.all([processDigestItems(), processResults()]);
  console.log(`Auto articles run complete. ${fromDigest} from digest, ${fromResults} from results.`);
  return { fromDigest, fromResults, total: fromDigest + fromResults };
}

if (require.main === module) {
  ingestAutoArticles()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Auto articles run failed:", err);
      process.exit(1);
    });
}

module.exports = { ingestAutoArticles };
