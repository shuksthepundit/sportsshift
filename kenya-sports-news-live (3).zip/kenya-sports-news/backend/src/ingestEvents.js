require("dotenv").config();
const db = require("./db");
const { fetchSportsEvents } = require("./ticketmaster");
const { COUNTRIES } = require("./sources");

const insertStmt = db.prepare(`
  INSERT OR IGNORE INTO events
    (name, sport, venue_name, venue_city, country_code, event_date, sponsor_name, ticket_url, image_url)
  VALUES
    (@name, @sport, @venue_name, @venue_city, @country_code, @event_date, @sponsor_name, @ticket_url, @image_url)
`);

const existsStmt = db.prepare(`SELECT 1 FROM events WHERE ticket_url = ?`);

async function ingestEvents() {
  console.log("Starting events ingestion run...");
  let totalAdded = 0;

  for (const country of COUNTRIES) {
    const events = await fetchSportsEvents(country.code);
    let added = 0;

    for (const event of events) {
      if (existsStmt.get(event.ticketUrl)) continue;
      insertStmt.run({
        name: event.name,
        sport: event.sport,
        venue_name: event.venueName,
        venue_city: event.venueCity,
        country_code: event.countryCode,
        event_date: event.eventDate,
        sponsor_name: event.sponsorName,
        ticket_url: event.ticketUrl,
        image_url: event.imageUrl,
      });
      added++;
    }

    totalAdded += added;
    console.log(`[Ticketmaster: ${country.name}] added ${added} (${events.length} found)`);
  }

  console.log(`Events ingestion run complete. ${totalAdded} new event(s) added.`);
  return { totalAdded };
}

if (require.main === module) {
  ingestEvents()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Events ingestion run failed:", err);
      process.exit(1);
    });
}

module.exports = { ingestEvents };
