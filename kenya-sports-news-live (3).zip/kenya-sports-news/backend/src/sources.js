// Feed sources to ingest, grouped by country.
//
// IMPORTANT: news sites change their RSS paths often (some drop RSS entirely when they
// redesign). Treat this list as a starting point, not a guarantee — before your first real
// ingest run, open each `feedUrl` in a browser and confirm it returns XML, not a 404/HTML
// page. Most WordPress-based sites (Capital FM, KBC, The Star) expose a feed at
// `<section-url>/feed/`. Sites built on custom CMSs (Nation.Africa, Standard) sometimes
// publish a dedicated RSS index instead — check standardmedia.co.ke/rssfeeds for the
// current list of Standard Group feeds.
//
// country_code follows ISO 3166-1 alpha-2. Add a new country by adding entries here —
// nothing else in the pipeline needs to change.

const SOURCES = [
  {
    countryCode: "KE",
    name: "Capital Sports",
    feedUrl: "https://www.capitalfm.co.ke/sports/feed/",
  },
  {
    countryCode: "KE",
    name: "The Star Kenya - Sports",
    feedUrl: "https://www.the-star.co.ke/sports/rss",
  },
  {
    countryCode: "KE",
    name: "KBC Sports",
    feedUrl: "https://www.kbc.co.ke/category/sports/feed/",
  },
  {
    countryCode: "KE",
    name: "Standard Sports",
    // Confirm the exact sports-section path at https://www.standardmedia.co.ke/rssfeeds
    feedUrl: "https://www.standardmedia.co.ke/rss/sports.php",
  },
];

// Ordered Kenya-first, then other African countries, then the rest can be added the
// same way. Ticketmaster's Discovery API doesn't have event inventory in every one of
// these countries yet — ingestEvents.js just logs 0 results and moves on when that
// happens, it doesn't fail the run.
const COUNTRIES = [
  { code: "KE", name: "Kenya", flag: "\uD83C\uDDF0\uD83C\uDDEA" },
  { code: "NG", name: "Nigeria", flag: "\uD83C\uDDF3\uD83C\uDDEC" },
  { code: "ZA", name: "South Africa", flag: "\uD83C\uDDFF\uD83C\uDDE6" },
  { code: "GH", name: "Ghana", flag: "\uD83C\uDDEC\uD83C\uDDED" },
  { code: "EG", name: "Egypt", flag: "\uD83C\uDDEA\uD83C\uDDEC" },
  { code: "ET", name: "Ethiopia", flag: "\uD83C\uDDEA\uD83C\uDDF9" },
  { code: "TZ", name: "Tanzania", flag: "\uD83C\uDDF9\uD83C\uDDFF" },
  { code: "UG", name: "Uganda", flag: "\uD83C\uDDFA\uD83C\uDDEC" },
  { code: "MA", name: "Morocco", flag: "\uD83C\uDDF2\uD83C\uDDE6" },
  { code: "SN", name: "Senegal", flag: "\uD83C\uDDF8\uD83C\uDDF3" },
  { code: "CI", name: "Ivory Coast", flag: "\uD83C\uDDE8\uD83C\uDDEE" },
  { code: "CM", name: "Cameroon", flag: "\uD83C\uDDE8\uD83C\uDDF2" },
  // Add more countries here the same way as you expand beyond Africa —
  // { code: "GB", name: "United Kingdom", flag: "🇬🇧" }, etc.
];

// Search terms used for YouTube ingestion, per country. Kept generic (name + sport
// keywords) so adding a country to COUNTRIES above is enough for RSS + events; add an
// entry here too if you want more targeted YouTube queries for that country (e.g. a
// specific league or national team name pulls better results than the generic form).
const YOUTUBE_QUERIES_BY_COUNTRY = {
  KE: ["Kenya sports highlights", "Harambee Stars", "Kenya athletics"],
  NG: ["Nigeria sports highlights", "Super Eagles"],
  ZA: ["South Africa sports highlights", "Bafana Bafana", "Springboks"],
  GH: ["Ghana sports highlights", "Black Stars"],
  EG: ["Egypt sports highlights", "Pharaohs football"],
  ET: ["Ethiopia sports highlights", "Ethiopia athletics"],
  TZ: ["Tanzania sports highlights", "Taifa Stars"],
  UG: ["Uganda sports highlights", "Cranes football"],
  MA: ["Morocco sports highlights", "Atlas Lions"],
  SN: ["Senegal sports highlights", "Lions of Teranga"],
  CI: ["Ivory Coast sports highlights", "Elephants football"],
  CM: ["Cameroon sports highlights", "Indomitable Lions"],
};

// Queries with no single-country focus — global tournaments, awards, sponsor news.
const GLOBAL_YOUTUBE_QUERIES = [
  "World Cup highlights",
  "Olympics highlights",
  "Champions League highlights",
  "African Cup of Nations highlights",
  "sports awards ceremony",
];

const SPORTS = [
  "Football",
  "Athletics",
  "Rugby",
  "Volleyball",
  "Basketball",
  "Boxing",
  "Cricket",
  "Motorsport",
  "Golf",
  "Other",
];

module.exports = {
  SOURCES,
  COUNTRIES,
  SPORTS,
  YOUTUBE_QUERIES_BY_COUNTRY,
  GLOBAL_YOUTUBE_QUERIES,
};
