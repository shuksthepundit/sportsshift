require("dotenv").config();
const db = require("./db");
const { searchSportsVideos } = require("./youtube");
const { classifyArticle } = require("./claude");
const { COUNTRIES, YOUTUBE_QUERIES_BY_COUNTRY, GLOBAL_YOUTUBE_QUERIES } = require("./sources");

const insertStmt = db.prepare(`
  INSERT OR IGNORE INTO videos
    (title, description, video_url, thumbnail_url, channel_name, country_code, sport, published_at)
  VALUES
    (@title, @description, @video_url, @thumbnail_url, @channel_name, @country_code, @sport, @published_at)
`);

const existsStmt = db.prepare(`SELECT 1 FROM videos WHERE video_url = ?`);

async function ingestQuery(query, defaultCountryCode) {
  const videos = await searchSportsVideos(query);
  let added = 0;

  for (const video of videos) {
    if (existsStmt.get(video.videoUrl)) continue;

    // Reuse the same Claude classifier used for articles, since it already returns a
    // sport + country tag from a title/snippet — keeps tagging logic in one place.
    const { sport, countryCode } = await classifyArticle({
      title: video.title,
      snippet: video.description,
      defaultCountryCode,
    });

    insertStmt.run({
      title: video.title,
      description: video.description || null,
      video_url: video.videoUrl,
      thumbnail_url: video.thumbnailUrl || null,
      channel_name: video.channelName || null,
      country_code: countryCode,
      sport,
      published_at: video.publishedAt || null,
    });
    added++;
  }
  return added;
}

async function ingestVideos() {
  console.log("Starting video ingestion run...");
  let totalAdded = 0;

  for (const country of COUNTRIES) {
    const queries = YOUTUBE_QUERIES_BY_COUNTRY[country.code] || [`${country.name} sports highlights`];
    for (const query of queries) {
      const added = await ingestQuery(query, country.code);
      totalAdded += added;
      console.log(`[YouTube: ${country.name} — "${query}"] added ${added}`);
    }
  }

  for (const query of GLOBAL_YOUTUBE_QUERIES) {
    const added = await ingestQuery(query, null);
    totalAdded += added;
    console.log(`[YouTube: Global — "${query}"] added ${added}`);
  }

  console.log(`Video ingestion run complete. ${totalAdded} new video(s) added.`);
  return { totalAdded };
}

if (require.main === module) {
  ingestVideos()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Video ingestion run failed:", err);
      process.exit(1);
    });
}

module.exports = { ingestVideos };
