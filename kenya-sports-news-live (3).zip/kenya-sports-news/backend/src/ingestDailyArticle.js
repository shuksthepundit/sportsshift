require("dotenv").config();
const db = require("./db");
const { generateDailyArticle } = require("./dailyArticleGenerator");

const upsertStmt = db.prepare(`
  INSERT INTO daily_articles (title, body, summary, published_date)
  VALUES (@title, @body, @summary, @published_date)
  ON CONFLICT(published_date) DO UPDATE SET
    title = excluded.title,
    body = excluded.body,
    summary = excluded.summary,
    created_at = datetime('now')
`);

// Keep a rolling archive rather than growing forever.
const pruneStmt = db.prepare(`
  DELETE FROM daily_articles WHERE published_date < date('now', '-60 day')
`);

async function publishDailyArticle() {
  console.log("Generating today's roundup article...");
  const article = await generateDailyArticle();

  if (!article) {
    console.log("Daily article generation produced nothing this run — skipping publish.");
    return { published: false };
  }

  const publishedDate = new Date().toISOString().slice(0, 10);
  upsertStmt.run({
    title: article.title,
    body: article.body,
    summary: article.summary || null,
    published_date: publishedDate,
  });
  pruneStmt.run();

  console.log(`Published daily article for ${publishedDate}: "${article.title}"`);
  return { published: true, publishedDate, title: article.title };
}

if (require.main === module) {
  publishDailyArticle()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Daily article publish run failed:", err);
      process.exit(1);
    });
}

module.exports = { publishDailyArticle };
