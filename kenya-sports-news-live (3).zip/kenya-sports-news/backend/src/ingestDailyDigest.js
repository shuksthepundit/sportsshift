require("dotenv").config();
const db = require("./db");
const { fetchDailyDigest } = require("./dailyDigestSearch");

const insertStmt = db.prepare(`
  INSERT OR IGNORE INTO daily_digest (headline, summary, sport, country_code, source_url)
  VALUES (@headline, @summary, @sport, @country_code, @source_url)
`);

// Keep roughly the last two ingestion cycles (this runs every DAILY_DIGEST_INTERVAL_HOURS,
// default 12h) so the sidebar doesn't grow unbounded.
const pruneStmt = db.prepare(`
  DELETE FROM daily_digest WHERE ingested_at < datetime('now', '-2 day')
`);

async function ingestDailyDigest() {
  console.log("Starting daily digest ingestion run...");
  const items = await fetchDailyDigest();

  let added = 0;
  for (const item of items) {
    if (!item.headline || !item.url) continue;
    insertStmt.run({
      headline: item.headline,
      summary: item.summary || null,
      sport: item.sport || null,
      country_code: item.country || null,
      source_url: item.url,
    });
    added++;
  }

  pruneStmt.run();

  console.log(`Daily digest ingestion complete. ${added} new item(s) added.`);
  return { added };
}

if (require.main === module) {
  ingestDailyDigest()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Daily digest ingestion run failed:", err);
      process.exit(1);
    });
}

module.exports = { ingestDailyDigest };
