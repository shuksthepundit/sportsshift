require("dotenv").config();
const express = require("express");
const cors = require("cors");
const cron = require("node-cron");
const newsRoutes = require("./routes/news");
const videoRoutes = require("./routes/videos");
const eventRoutes = require("./routes/events");
const liveScoresRoutes = require("./routes/liveScores");
const digestRoutes = require("./routes/digest");
const dailyArticleRoutes = require("./routes/dailyArticle");
const autoArticlesRoutes = require("./routes/autoArticles");
const { ingestAll } = require("./ingest");
const { ingestVideos } = require("./ingestVideos");
const { ingestEvents } = require("./ingestEvents");
const { ingestLiveScores } = require("./ingestLiveScores");
const { ingestDailyDigest } = require("./ingestDailyDigest");
const { publishDailyArticle } = require("./ingestDailyArticle");
const { ingestAutoArticles } = require("./ingestAutoArticles");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => res.json({ ok: true }));
app.use("/api", newsRoutes);
app.use("/api", videoRoutes);
app.use("/api", eventRoutes);
app.use("/api", liveScoresRoutes);
app.use("/api", digestRoutes);
app.use("/api", dailyArticleRoutes);
app.use("/api", autoArticlesRoutes);

async function ingestEverything() {
  const [articles, videos, events] = await Promise.all([
    ingestAll(),
    ingestVideos(),
    ingestEvents(),
  ]);
  return { articles, videos, events };
}

// Manual trigger, useful for a hosting provider's own scheduler (e.g. a Render/Railway
// cron job hitting this endpoint) instead of the in-process one below.
app.post("/api/ingest", async (_req, res) => {
  try {
    const results = await ingestEverything();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Separate manual triggers for the two AI-search-powered pipelines, since they run on
// their own cadences (12h for live scores, 12h for the digest) rather than joining
// the RSS/video/events run above.
app.post("/api/ingest/live-scores", async (_req, res) => {
  try {
    const results = await ingestLiveScores();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/api/ingest/digest", async (_req, res) => {
  try {
    const results = await ingestDailyDigest();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/api/ingest/daily-article", async (_req, res) => {
  try {
    const results = await publishDailyArticle();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/api/ingest/auto-articles", async (_req, res) => {
  try {
    const results = await ingestAutoArticles();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`API listening on http://localhost:${PORT}`);
});

// Built-in scheduler. Set INGEST_INTERVAL_MINUTES=0 to disable if you'd rather trigger
// POST /api/ingest from an external scheduler.
const intervalMinutes = Number(process.env.INGEST_INTERVAL_MINUTES ?? 30);
if (intervalMinutes > 0) {
  cron.schedule(`*/${intervalMinutes} * * * *`, () => {
    console.log("Running scheduled ingestion...");
    ingestEverything().catch((err) => console.error("Scheduled ingestion failed:", err));
  });
  // Also run once on boot so the app isn't empty on first start.
  ingestEverything().catch((err) => console.error("Initial ingestion failed:", err));
}

// Second, independent cadence for live scores ingestion — every 12 hours. (Previously
// there was also a 15-minute cycle; that's been removed, so this 12-hour run is now
// the only live scores refresh.) Set LIVE_SCORES_INTERVAL_HOURS=0 to disable.
const liveScoresIntervalHours = Number(process.env.LIVE_SCORES_INTERVAL_HOURS ?? 12);
if (liveScoresIntervalHours > 0) {
  cron.schedule(`0 */${liveScoresIntervalHours} * * *`, () => {
    console.log("Running scheduled live scores ingestion (12-hour cycle)...");
    ingestLiveScores().catch((err) => console.error("Scheduled live scores ingestion failed:", err));
  });
  // Run once on boot so the app isn't empty on first start.
  ingestLiveScores().catch((err) => console.error("Initial live scores ingestion failed:", err));
}

// The AI-search daily digest is heavier (a full web-search-augmented Claude call) and
// doesn't need live-score freshness, so it runs on its own slower cadence — every 12
// hours by default. Set DAILY_DIGEST_INTERVAL_HOURS=0 to disable.
const digestIntervalHours = Number(process.env.DAILY_DIGEST_INTERVAL_HOURS ?? 12);
if (digestIntervalHours > 0) {
  cron.schedule(`0 */${digestIntervalHours} * * *`, () => {
    console.log("Running scheduled daily digest ingestion...");
    ingestDailyDigest().catch((err) => console.error("Scheduled daily digest ingestion failed:", err));
  });
  ingestDailyDigest().catch((err) => console.error("Initial daily digest ingestion failed:", err));
}

// Publishes one AI-written roundup article automatically every 24 hours. Re-runs the
// same calendar day just update that day's article in place (see ingestDailyArticle.js)
// rather than creating duplicates. Set DAILY_ARTICLE_INTERVAL_HOURS=0 to disable.
const dailyArticleIntervalHours = Number(process.env.DAILY_ARTICLE_INTERVAL_HOURS ?? 24);
if (dailyArticleIntervalHours > 0) {
  cron.schedule(`0 */${dailyArticleIntervalHours} * * *`, () => {
    console.log("Running scheduled daily article publish...");
    publishDailyArticle().catch((err) => console.error("Scheduled daily article publish failed:", err));
  });
  publishDailyArticle().catch((err) => console.error("Initial daily article publish failed:", err));
}

// Publishes a separate article per new digest headline / new match result (not one
// combined roundup — see AUTO_ARTICLES_MAX_PER_RUN in .env to bound cost per run).
// Every 24 hours by default. Set AUTO_ARTICLES_INTERVAL_HOURS=0 to disable.
const autoArticlesIntervalHours = Number(process.env.AUTO_ARTICLES_INTERVAL_HOURS ?? 24);
if (autoArticlesIntervalHours > 0) {
  cron.schedule(`0 */${autoArticlesIntervalHours} * * *`, () => {
    console.log("Running scheduled auto articles generation...");
    ingestAutoArticles().catch((err) => console.error("Scheduled auto articles generation failed:", err));
  });
  ingestAutoArticles().catch((err) => console.error("Initial auto articles generation failed:", err));
}
