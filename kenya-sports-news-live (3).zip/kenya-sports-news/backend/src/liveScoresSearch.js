const { searchForJSON } = require("./aiSearch");

const LIVE_SCORES_PROMPT = `Search flashscore.com and other reliable live sports score sites for the CURRENT state of sports scores, with priority on Kenyan and African football/athletics/rugby but also covering major global fixtures (Premier League, Champions League, etc).

Return ONLY a single JSON object, no prose, no markdown fences, with exactly this shape:
{
  "live": [
    {
      "sport": "Football",
      "competition": "Kenyan Premier League",
      "homeTeam": "Gor Mahia",
      "awayTeam": "AFC Leopards",
      "homeScore": "1",
      "awayScore": "0",
      "minute": "63'"
    }
  ],
  "results": [
    {
      "sport": "Football",
      "competition": "Kenyan Premier League",
      "homeTeam": "Tusker FC",
      "awayTeam": "Kakamega Homeboyz",
      "homeScore": "2",
      "awayScore": "1",
      "matchDate": "2026-07-14"
    }
  ]
}

STRICT rules:
- "live" must ONLY contain matches that are actually in progress right now (currently being played) — never fixtures that haven't kicked off, and never finished matches.
- "results" must ONLY contain matches that finished earlier TODAY or YESTERDAY (in East Africa Time) — never anything older.
- If you can't confirm a match's real-time status, leave it out rather than guessing.
- matchDate must be an ISO date (YYYY-MM-DD).
- If there are genuinely no live matches or no recent results right now, return an empty array for that field — do not invent matches.`;

async function fetchLiveAndResults() {
  const data = await searchForJSON(LIVE_SCORES_PROMPT, { maxTokens: 3000 });
  if (!data) return { live: [], results: [] };
  return {
    live: Array.isArray(data.live) ? data.live : [],
    results: Array.isArray(data.results) ? data.results : [],
  };
}

module.exports = { fetchLiveAndResults };
