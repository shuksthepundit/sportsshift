# Sports Shifts P&P — African Sports News (Kenya-first)

An AI-assisted news aggregator that pulls sports news from Kenyan outlets, uses Claude to
classify each story by **sport** and **country**, and serves it through a filterable web app.
Built to extend to other African countries by adding feed sources — no schema or pipeline
changes needed.

See [ARCHITECTURE.md](./ARCHITECTURE.md) for the design reasoning.

## Stack

- **Backend**: Node.js + Express + SQLite (`better-sqlite3`), `rss-parser` for feeds,
  `@anthropic-ai/sdk` for classification, `node-cron` for scheduled ingestion.
- **Frontend**: React + Vite, no UI framework dependency.

## Setup

### 1. Backend

```bash
cd backend
cp .env.example .env
# edit .env and add your ANTHROPIC_API_KEY
npm install
npm run ingest    # one-off: fetch + classify + store the current news
npm start          # starts the API on :4000 and the scheduler
```

The scheduler (`INGEST_INTERVAL_MINUTES` in `.env`) re-runs ingestion automatically. Set it
to `0` if you'd rather trigger `POST /api/ingest` from an external scheduler (e.g. your
hosting provider's cron).

### 2. Frontend

```bash
cd frontend
npm install
npm run dev         # starts on :5173, proxies /api to :4000
```

Open the printed localhost URL. You should see Kenyan sports stories grouped by sport, with
a country tab for Kenya (more countries appear automatically once you add sources for them).

## Before you deploy

1. **Verify the RSS feed URLs in `backend/src/sources.js`.** News sites change these often —
   open each one in a browser first and confirm it returns XML.
2. **Get an Anthropic API key** and set `ANTHROPIC_API_KEY` in `backend/.env` (or your
   host's environment variables).
3. **Pick where ingestion runs.** The built-in `node-cron` scheduler works for a single
   long-running server (e.g. a VM, Railway, Render). On serverless hosting, disable it
   (`INGEST_INTERVAL_MINUTES=0`) and call `POST /api/ingest` from that platform's own
   scheduled-function feature instead.
4. **Swap SQLite for Postgres** if you expect real concurrent traffic — the schema in
   `backend/src/db.js` is simple enough to port directly.

## Adding a new country

Add one or more entries to the `SOURCES` array in `backend/src/sources.js`:

```js
{ countryCode: "NG", name: "Some Nigerian Sports Outlet", feedUrl: "https://.../feed" },
```

and a matching entry in `COUNTRIES` so it shows up as a tab in the UI. Nothing else changes —
the ingestion pipeline, API, and frontend all read from this config.

## API reference

- `GET /api/news?country=KE&sport=Athletics&limit=30` — list articles, filterable
- `GET /api/countries` — configured countries with article counts
- `GET /api/sports` — sport categories with article counts
- `POST /api/ingest` — trigger an ingestion run on demand
