# Architecture — African Sports News Aggregator (Kenya-first)

## The core recommendation

**Scheduled ingestion, not live search per request.** A user opening the app should get an
instant response from your own database, not wait on a live web search + AI classification
round-trip. So:

```
RSS feeds (Nation Sports, Standard Sports, Citizen Digital, Pulse Sports, Capital Sports, ...)
        │  every N minutes (cron)
        ▼
  Ingestion worker  ──►  Claude API (classify + tag + summarize)  ──►  SQLite/Postgres
        │
        ▼
  REST API (Express)  ◄──────────────  React frontend
```

Why this over "AI searches live every time someone opens the app":
- **Cost**: classifying an article once at ingest time is far cheaper than re-searching/
  re-summarizing on every page view.
- **Speed**: the frontend hits your DB, not an LLM call — sub-100ms responses.
- **Reliability**: if a news site or the AI API is briefly down, users still see the last
  good data instead of a blank screen.
- **Auditability**: you can see exactly what was ingested and when, and re-run classification
  if you improve the prompt later.

The AI's job is narrow and well-suited to this: given a headline + snippet, decide **which
sport** it belongs to, **which country** it's about (useful once you add pan-African sources
that cover multiple countries in one feed), and write a **short neutral summary**. That's a
cheap, reliable classification task — not open-ended research — so a small/fast model call per
article is the right shape.

## Why start with RSS feeds over a paid News API

Kenyan sports outlets (Nation Sports, Standard Sports, Citizen Digital, Capital Sports, Pulse
Sports Kenya, The Star) all publish RSS feeds already, so ingestion is free and doesn't depend
on a third-party news API's coverage of African sport (which is often thin). You can add
NewsAPI/GNews as a supplementary source later without changing the pipeline — it's just
another fetcher that feeds the same classification step.

## Data model (extensible from day one)

```
articles
  id, title, summary, url (unique), source_name, source_url,
  country_code (e.g. "KE"), sport (enum-ish string), image_url,
  published_at, ingested_at

sources
  id, name, feed_url, country_code, active
```

`country_code` and `sport` are plain strings, not hard-coded enums in the schema — adding
Uganda or Nigeria later is a config change (new rows in `sources`), not a migration.

## Repo layout

```
backend/
  src/
    db.js            SQLite setup + schema
    sources.js        list of RSS feeds to ingest, per country
    claude.js          thin wrapper around the Anthropic API for classification
    ingest.js          fetch feeds -> dedupe -> classify -> store (run via cron or manually)
    routes/news.js     GET /api/news, /api/countries, /api/sports
    server.js           Express app entry point
frontend/
  src/
    api.js             fetch helpers
    App.jsx             country tabs + sport filter + news grid
    components/         NewsCard, CountryTabs, SportFilter, Header
```

## Scaling path

1. **Now**: SQLite, single ingestion process, cron every 15–30 min. Fine for one country.
2. **Multi-country**: add feeds to `sources.js` with their `country_code`; no code changes to
   ingestion or API needed since filtering is already generic.
3. **Real traffic**: swap SQLite → Postgres (schema is already relational/simple), move
   ingestion to a proper job queue (BullMQ/Cloud Scheduler) instead of in-process cron,
   add Redis caching in front of `/api/news`.
4. **Push notifications / breaking news**: since classification already happens at ingest
   time, you can trivially add a rule like "if sport=athletics and country=KE and published
   in last 10 min → push" without touching the AI layer.

## What you still need to supply

- An `ANTHROPIC_API_KEY` (backend/.env)
- A place to run the ingestion worker on a schedule (a cron job, a serverless scheduled
  function, or just `node src/ingest.js` on a timer) — a self-contained repo can't schedule
  itself once deployed.
