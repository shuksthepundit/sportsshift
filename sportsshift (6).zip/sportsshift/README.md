# SportsShift — Kenya Sports News & Welfare Tracker

An AI-assisted sports news aggregator, Kenya-first. Pulls sports news from Kenyan `.co.ke`
outlets, classifies each story by **sport**, **country**, and — for Kenya — **county**, and
adds a dedicated **welfare/development tracker** covering progress, gaps, opportunities, and
missed opportunities affecting the welfare of sportsmen and women (funding, facilities,
sports-legislation implementation, anti-doping, gender equity, referee/official welfare).
Built to extend to other countries by adding feed sources — no schema or pipeline changes
needed for that part.

See [ARCHITECTURE.md](./ARCHITECTURE.md) for the design reasoning.

## Stack

- **Backend**: Node.js + Express + SQLite (`better-sqlite3`), `rss-parser` for feeds,
  `@anthropic-ai/sdk` for classification and web-search-grounded research, `node-cron` for
  scheduled ingestion.
- **Frontend**: React + Vite, no UI framework dependency.

## Setup

### 1. Backend

```bash
cd backend
cp .env.example .env
# edit .env and add your ANTHROPIC_API_KEY
npm install
npm run ingest            # one-off: fetch + classify + store the current news
npm run ingest:welfare    # one-off: populate the welfare/development tracker
npm start                 # starts the API on :4000 and the scheduler
```

The scheduler re-runs ingestion automatically every `INGEST_INTERVAL_MINUTES` (defaults to
**1440 — i.e. once every 24 hours**, matching "reupdate new content daily"). Lower it in
`.env` if you want fresher headlines through the day, or set it to `0` and trigger
`POST /api/ingest` from an external scheduler (e.g. your host's own cron) instead.

### 2. Frontend

```bash
cd frontend
npm install
npm run dev         # starts on :5173, proxies /api to :4000
```

Open the printed localhost URL. You'll see Kenyan sports stories grouped by sport, a county
filter once Kenya is the active tab, and the welfare/development tracker below the main
news grid.

## What's covered

- **Sports coverage**: Football, Athletics, Rugby, Volleyball, Basketball, Boxing, Cricket,
  Motorsport, Golf, and a dedicated **Sports Legislation & Governance** category — plus
  "Other" as a catch-all.
- **Geography**: national Kenyan coverage, all 47 counties (auto-tagged by the classifier),
  and country/continent tagging for stories beyond Kenya — every article is tagged with one
  of six **continents** (Africa, Asia, Europe, North America, South America, Oceania),
  looked up directly from `COUNTRIES` in `sources.js` rather than guessed from the article
  text. Africa leads (11 African countries have real feeds or are ready for one — see
  "Adding a new country" below), and one flagship market is wired up with a real feed on
  every other continent (India, UK, USA, Brazil, Australia) so the app has working global
  coverage from day one. Add more countries the same way as you go.
- **Daily refresh**: the built-in scheduler defaults to a 24-hour cycle for RSS news,
  videos, events, and the welfare tracker. A **"⟳ Refresh now" button** in the UI also
  calls `POST /api/ingest` on demand for anyone who wants the latest headlines immediately
  instead of waiting for the next scheduled run.
- **Brief summaries, limited redirects**: every article gets a short, neutral one-sentence
  summary from Claude at classification time (`claude.js`), with a sentence-aware fallback
  trimmer in `ingest.js` if that call fails, so a "summary" is never just a raw, oversized
  RSS snippet. Clicking a news card opens an in-app detail view with that summary — it
  does **not** redirect to the source automatically. The original article link only
  appears once, as a single labeled button inside that detail view, so leaving the site is
  always one deliberate click rather than an automatic redirect from browsing the grid.
- **Welfare & development tracker**: a separate `welfare_reports` table populated by a
  web-search-grounded Claude call (`welfareSearch.js` / `ingestWelfareReports.js`), tagged
  by category (Athlete Welfare & Pay, Facilities & Infrastructure, Grassroots & Talent
  Development, Sports Legislation & Governance, Anti-Doping & Integrity, Gender Equity in
  Sport, Referee & Match Official Welfare, Funding & Sponsorship) and status (progress /
  gap / opportunity / missed opportunity).

## Before you deploy

1. **Verify the RSS feed URLs in `backend/src/sources.js`.** News sites change these often
   — open each one in a browser first and confirm it returns XML.
2. **Get an Anthropic API key** and set `ANTHROPIC_API_KEY` in `backend/.env` (or your
   host's environment variables). The welfare tracker and live-scores/digest features use
   Claude's web search tool, which has a per-search cost — check your usage dashboard if
   you're cost-sensitive, and use the `*_INTERVAL_HOURS` env vars to slow those down.
3. **Pick where ingestion runs.** The built-in `node-cron` scheduler works for a single
   long-running server (a VM, Railway, Render). On serverless hosting, disable it
   (`INGEST_INTERVAL_MINUTES=0`) and call `POST /api/ingest` from that platform's own
   scheduled-function feature instead.
4. **Swap SQLite for Postgres** if you expect real concurrent traffic — the schema in
   `backend/src/db.js` is simple enough to port directly.
5. **Review welfare tracker items before treating them as confirmed.** Every row inserted
   by `ingestWelfareReports.js` is stored with `reviewed = 0`. These are AI-drafted,
   web-search-sourced observations, not verified investigative reporting — claims about
   welfare failures can name real federations, counties, or officials, so an editor should
   check each item against its `source_url` before it's presented as established fact. Flip
   `reviewed` to `1` in the database (or build a small admin UI for it) once checked.

## Adding a new country

Add one or more entries to the `SOURCES` array in `backend/src/sources.js`:

```js
{ countryCode: "NG", sourceType: "news", name: "Some Nigerian Sports Outlet", feedUrl: "https://.../feed" },
```

and a matching entry in `COUNTRIES` so it shows up as a tab in the UI. Nothing else changes
— the ingestion pipeline, API, and frontend all read from this config.

## Adding blogs, analysts, commentators, and referee sources

`SOURCES` entries carry a `sourceType` (`news`, `blog`, `analyst`, `commentator`,
`referee`). Two placeholder entries are included with `feedUrl: null` — `ingest.js` skips
these safely and logs that they're not configured yet. To activate one:

1. Confirm the source actually publishes an RSS/Atom feed (open the URL in a browser and
   check it's XML, not HTML — most independent blogs and personal commentator sites don't
   have one, in which case a generic RSS-based pipeline can't ingest them).
2. Fill in the real `feedUrl` and set `sourceType` appropriately.
3. If a source has no feed at all, you'd need a small dedicated scraper for that one page
   rather than the generic RSS pipeline — happy to help build one for a specific source if
   you tell me which one.

## On social media ingestion

Facebook, X/Twitter, Instagram, and TikTok all prohibit scraping outside their official
APIs in their Terms of Service, so this repo doesn't include a scraper for them. What's
here instead: a `SOCIAL_SOURCES` config stub in `sources.js` (disabled by default) — get
developer credentials from each platform, set `enabled: true`, add the token to `.env`, and
implement that platform's documented search/timeline endpoint in a new `ingestSocial.js`
that follows the same insert-into-`articles` pattern as `ingest.js`.

## On "advance a right shift"

This build ingests and classifies real reporting as-is — headlines and summaries aren't
rewritten to fit a political or editorial lean, since altering facts to push a direction
would make the tracker a source of misinformation rather than a news aggregator. If you
want the site to carry a specific editorial position (e.g. advocacy for particular sports
policy reforms), the clean way to do that is a distinct, clearly labeled "Analysis &
Opinion" section with named contributors — kept visibly separate from the aggregated news
feed and the welfare tracker above.

## API reference

- `GET /api/news?country=KE&sport=Athletics&county=Nakuru&continent=Africa&limit=30` —
  list articles, filterable by country, sport, continent, and (for Kenya) county
- `GET /api/countries` — configured countries with article counts (each includes its
  `continent`)
- `GET /api/continents` — the six continents this app tags, with article counts, in
  Africa-first order
- `GET /api/counties` — Kenya's 47 counties + National, with article counts
- `GET /api/sports` — sport categories with article counts
- `GET /api/welfare-reports?category=...&status=...&county=...` — welfare/development
  tracker items
- `GET /api/welfare-categories` — welfare categories with counts per status, for a
  scorecard view
- `POST /api/ingest` — trigger a news/video/events ingestion run on demand
- `POST /api/ingest/welfare` — trigger a welfare tracker ingestion run on demand
