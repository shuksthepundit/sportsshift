import { useEffect, useState } from "react";
import { fetchNews, fetchCountries, fetchCounties, fetchSports, fetchContinents } from "./api";
import Header from "./components/Header.jsx";
import FeatureStrip from "./components/FeatureStrip.jsx";
import ContinentTabs from "./components/ContinentTabs.jsx";
import CountryTabs from "./components/CountryTabs.jsx";
import SportFilter from "./components/SportFilter.jsx";
import CountyFilter from "./components/CountyFilter.jsx";
import NewsCard from "./components/NewsCard.jsx";
import ArticleDetail from "./components/ArticleDetail.jsx";
import RefreshButton from "./components/RefreshButton.jsx";
import Sidebar from "./components/Sidebar.jsx";
import DailyArticleBanner from "./components/DailyArticleBanner.jsx";
import AutoArticlesSection from "./components/AutoArticlesSection.jsx";
import WelfareTracker from "./components/WelfareTracker.jsx";

export default function App() {
  const [continents, setContinents] = useState([]);
  const [countries, setCountries] = useState([]);
  const [counties, setCounties] = useState([]);
  const [sports, setSports] = useState([]);
  const [activeContinent, setActiveContinent] = useState(null);
  const [activeCountry, setActiveCountry] = useState("KE");
  const [activeSport, setActiveSport] = useState(null);
  const [activeCounty, setActiveCounty] = useState(null);
  const [articles, setArticles] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ready | error
  const [openArticle, setOpenArticle] = useState(null); // article shown in the detail overlay

  function loadFilters() {
    fetchContinents().then(setContinents).catch(() => {});
    fetchCountries().then(setCountries).catch(() => {});
    fetchCounties().then(setCounties).catch(() => {});
    fetchSports().then(setSports).catch(() => {});
  }

  function loadArticles() {
    setStatus("loading");
    fetchNews({ country: activeCountry, sport: activeSport, county: activeCounty, continent: activeContinent })
      .then((data) => {
        setArticles(data.articles);
        setStatus("ready");
      })
      .catch(() => setStatus("error"));
  }

  useEffect(loadFilters, []);
  useEffect(loadArticles, [activeCountry, activeSport, activeCounty, activeContinent]);

  // Countries shown in the tab bar narrow to the active continent, so picking
  // "Oceania" doesn't leave Kenya's tab sitting there as if it were still relevant.
  const visibleCountries = activeContinent
    ? countries.filter((c) => c.continent === activeContinent)
    : countries;

  return (
    <div className="app">
      <Header />
      <FeatureStrip />

      <div className="home-layout">
        <main className="main">
          <div className="toolbar-row">
            <RefreshButton
              onRefreshed={() => {
                loadArticles();
                loadFilters();
              }}
            />
          </div>

          <DailyArticleBanner />

          {continents.length > 0 && (
            <ContinentTabs
              continents={continents}
              activeContinent={activeContinent}
              onSelect={(name) => {
                setActiveContinent(name);
                setActiveCountry(name ? null : "KE");
                setActiveSport(null);
                setActiveCounty(null);
              }}
            />
          )}

          {visibleCountries.length > 0 && (
            <CountryTabs
              countries={visibleCountries}
              activeCountry={activeCountry}
              onSelect={(code) => {
                setActiveCountry(code);
                setActiveSport(null);
                setActiveCounty(null);
              }}
            />
          )}

          {sports.length > 0 && (
            <SportFilter sports={sports} activeSport={activeSport} onSelect={setActiveSport} />
          )}

          {/* Counties only make sense once you're looking at Kenya specifically */}
          {activeCountry === "KE" && counties.length > 0 && (
            <CountyFilter counties={counties} activeCounty={activeCounty} onSelect={setActiveCounty} />
          )}

          {status === "loading" && <p className="status-message">Loading fixtures…</p>}

          {status === "error" && (
            <p className="status-message status-message--error">
              Couldn't reach the news API. Is the backend running on port 4000?
            </p>
          )}

          {status === "ready" && articles.length === 0 && (
            <p className="status-message">
              No stories yet for this filter. Try <strong>⟳ Refresh now</strong> above, or run{" "}
              <code>npm run ingest</code> in the backend.
            </p>
          )}

          {status === "ready" && articles.length > 0 && (
            <div className="news-grid">
              {articles.map((article) => (
                <NewsCard key={article.id} article={article} onOpen={setOpenArticle} />
              ))}
            </div>
          )}

          <AutoArticlesSection />

          <WelfareTracker />
        </main>

        <Sidebar />
      </div>

      <ArticleDetail article={openArticle} onClose={() => setOpenArticle(null)} />
    </div>
  );
}
