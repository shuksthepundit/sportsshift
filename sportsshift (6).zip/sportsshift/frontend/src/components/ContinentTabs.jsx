export default function ContinentTabs({ continents, activeContinent, onSelect }) {
  return (
    <nav className="continent-tabs" aria-label="Filter by continent">
      <button
        type="button"
        className={`continent-tab ${!activeContinent ? "is-active" : ""}`}
        onClick={() => onSelect(null)}
      >
        🌍 All Continents
      </button>
      {continents.map((c) => (
        <button
          key={c.name}
          type="button"
          className={`continent-tab ${activeContinent === c.name ? "is-active" : ""}`}
          onClick={() => onSelect(c.name)}
        >
          <span>{c.name}</span>
          <span className="continent-count">{c.articleCount}</span>
        </button>
      ))}
    </nav>
  );
}
