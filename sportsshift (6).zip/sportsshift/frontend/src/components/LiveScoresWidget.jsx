import { useEffect, useState, useCallback } from "react";
import { fetchFixtures, fetchLiveScores, fetchResults } from "../api";

// 2 minutes — the backend refreshes fixtures/live/results every 15 minutes by default
// (LIVE_SCORES_INTERVAL_MINUTES), but a shorter frontend poll means a match that just
// flipped to "live" or "finished" on the backend shows up here without a page reload.
const REFRESH_MS = 2 * 60 * 1000;

export default function LiveScoresWidget() {
  const [tab, setTab] = useState("live"); // "fixtures" | "live" | "results"
  const [fixtures, setFixtures] = useState([]);
  const [live, setLive] = useState([]);
  const [results, setResults] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ready | error
  const [lastUpdated, setLastUpdated] = useState(null);

  const load = useCallback(() => {
    Promise.all([fetchFixtures(), fetchLiveScores(), fetchResults()])
      .then(([fixturesData, liveData, resultsData]) => {
        setFixtures(fixturesData.matches);
        setLive(liveData.matches);
        setResults(resultsData.matches);
        setStatus("ready");
        setLastUpdated(new Date());
      })
      .catch(() => setStatus("error"));
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, REFRESH_MS);
    return () => clearInterval(id);
  }, [load]);

  const matches = tab === "fixtures" ? fixtures : tab === "live" ? live : results;

  return (
    <section className="sidebar-card">
      <div className="sidebar-card__header">
        <h3 className="sidebar-card__title">Scores</h3>
        {lastUpdated && (
          <span className="sidebar-card__updated">
            Updated {lastUpdated.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </span>
        )}
      </div>

      <div className="score-tabs">
        <button
          className={`score-tab ${tab === "fixtures" ? "score-tab--active" : ""}`}
          onClick={() => setTab("fixtures")}
        >
          Fixtures ({fixtures.length})
        </button>
        <button
          className={`score-tab ${tab === "live" ? "score-tab--active" : ""}`}
          onClick={() => setTab("live")}
        >
          <span className="live-dot" /> Live ({live.length})
        </button>
        <button
          className={`score-tab ${tab === "results" ? "score-tab--active" : ""}`}
          onClick={() => setTab("results")}
        >
          Results ({results.length})
        </button>
      </div>

      {status === "loading" && <p className="sidebar-card__status">Loading scores…</p>}
      {status === "error" && <p className="sidebar-card__status">Couldn't load scores.</p>}

      {status === "ready" && matches.length === 0 && (
        <p className="sidebar-card__status">
          {tab === "fixtures" && "No upcoming fixtures right now."}
          {tab === "live" && "No matches in play right now."}
          {tab === "results" && "No results in the last day."}
        </p>
      )}

      {status === "ready" && matches.length > 0 && (
        <ul className="match-list">
          {matches.map((m) => (
            <li key={m.id} className="match-row">
              <div className="match-row__competition">{m.competition || m.sport}</div>
              <div className="match-row__teams">
                <span>{m.home_team}</span>
                {tab === "fixtures" ? (
                  <span className="match-row__score match-row__score--vs">vs</span>
                ) : (
                  <span className="match-row__score">
                    {m.home_score ?? "-"} : {m.away_score ?? "-"}
                  </span>
                )}
                <span>{m.away_team}</span>
              </div>
              <div className="match-row__meta">
                {tab === "fixtures" && (
                  <span>
                    {m.match_date}
                    {m.kickoff_time ? ` · ${m.kickoff_time}` : ""}
                  </span>
                )}
                {tab === "live" && <span className="match-row__minute">{m.match_minute || "LIVE"}</span>}
                {tab === "results" && <span>{m.match_date}</span>}
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
