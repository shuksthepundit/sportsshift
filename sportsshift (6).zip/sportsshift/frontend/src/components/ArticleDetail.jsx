function timeAgo(isoString) {
  if (!isoString) return "";
  const diffMs = Date.now() - new Date(isoString).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

/**
 * Shown when a NewsCard is clicked, instead of redirecting straight to the source.
 * Reading the brief summary here is the default path; leaving the site to read the
 * full article is one deliberate click on the button below, not automatic.
 */
export default function ArticleDetail({ article, onClose }) {
  if (!article) return null;

  return (
    <div className="article-detail-backdrop" onClick={onClose}>
      <div className="article-detail" onClick={(e) => e.stopPropagation()}>
        <button type="button" className="article-detail-close" onClick={onClose} aria-label="Close">
          ✕
        </button>

        {article.image_url && (
          <div
            className="article-detail-image"
            style={{ backgroundImage: `url(${article.image_url})` }}
          />
        )}

        <div className="article-detail-body">
          <div className="news-card-meta">
            <span className="news-card-sport">{article.sport}</span>
            <span className="news-card-time">{timeAgo(article.published_at)}</span>
          </div>

          <h2 className="article-detail-title">{article.title}</h2>

          {article.summary && <p className="article-detail-summary">{article.summary}</p>}

          <div className="article-detail-source-out">
            <p className="article-detail-source-note">
              Brief summary of reporting by <strong>{article.source_name}</strong>. For the
              full article, photos, and context, visit the original source.
            </p>
            <a
              className="article-detail-source-button"
              href={article.url}
              target="_blank"
              rel="noopener noreferrer nofollow"
            >
              Read full article at {article.source_name} →
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
