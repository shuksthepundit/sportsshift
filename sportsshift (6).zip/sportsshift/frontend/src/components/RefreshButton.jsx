import { useState, useEffect, useCallback, useRef } from "react";
import { triggerIngest, fetchIngestStatus } from "../api";

/**
 * Manual "refresh now" control. The backend already re-ingests automatically every
 * 24 hours (see server.js), and this button lets someone pull the latest content
 * immediately instead of waiting — but it's capped to once every 24 hours too
 * (REFRESH_COOLDOWN_MINUTES on the backend), so it can't be used to spam upstream
 * AI-search/API calls. The button reflects that cooldown for real: on load it asks
 * the backend when content was last refreshed (GET /api/ingest/status) and disables
 * itself with a live countdown until the next refresh is actually allowed, and the
 * backend enforces the same window server-side regardless of what the button shows.
 */
export default function RefreshButton({ onRefreshed }) {
  const [state, setState] = useState("checking"); // checking | idle | loading | done | error | cooldown
  const [nextAvailableAt, setNextAvailableAt] = useState(null);
  const [countdown, setCountdown] = useState("");
  const tickRef = useRef(null);

  const applyStatus = useCallback((status) => {
    if (status.canRefreshNow) {
      setState("idle");
      setNextAvailableAt(null);
    } else {
      setState("cooldown");
      setNextAvailableAt(status.nextAvailableAt);
    }
  }, []);

  useEffect(() => {
    fetchIngestStatus()
      .then(applyStatus)
      .catch(() => setState("idle")); // if status can't be reached, fail open to idle
  }, [applyStatus]);

  // Live "Xh Ym" countdown while cooling down, ticking every minute; flips the button
  // back to "idle" itself the moment the 24 hours are up, no page reload needed.
  useEffect(() => {
    clearInterval(tickRef.current);
    if (state !== "cooldown" || !nextAvailableAt) {
      setCountdown("");
      return;
    }
    const update = () => {
      const msLeft = new Date(nextAvailableAt).getTime() - Date.now();
      if (msLeft <= 0) {
        setState("idle");
        setNextAvailableAt(null);
        setCountdown("");
        return;
      }
      const totalMinutes = Math.ceil(msLeft / 60000);
      const hours = Math.floor(totalMinutes / 60);
      const minutes = totalMinutes % 60;
      setCountdown(hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`);
    };
    update();
    tickRef.current = setInterval(update, 60000);
    return () => clearInterval(tickRef.current);
  }, [state, nextAvailableAt]);

  async function handleClick() {
    if (state === "loading" || state === "cooldown" || state === "checking") return;
    setState("loading");
    try {
      const result = await triggerIngest();
      setState("done");
      if (onRefreshed) onRefreshed(result);
      setTimeout(() => {
        // Re-check status rather than assuming — keeps the 24h window accurate even
        // if REFRESH_COOLDOWN_MINUTES differs from the default.
        fetchIngestStatus().then(applyStatus).catch(() => setState("idle"));
      }, 2500);
    } catch (err) {
      if (err.status === 429 && err.body?.nextAvailableAt) {
        // Another tab/user refreshed first — sync to the server's cooldown instead of
        // just showing a generic error.
        setState("cooldown");
        setNextAvailableAt(err.body.nextAvailableAt);
      } else {
        setState("error");
        setTimeout(() => setState("idle"), 3000);
      }
    }
  }

  const label =
    state === "checking"
      ? "⟳ Refresh now"
      : state === "loading"
      ? "Refreshing…"
      : state === "done"
      ? "Updated ✓"
      : state === "error"
      ? "Refresh failed"
      : state === "cooldown"
      ? `Next refresh in ${countdown || "…"}`
      : "⟳ Refresh now";

  const disabled = state === "loading" || state === "cooldown" || state === "checking";

  return (
    <button
      type="button"
      className={`refresh-button refresh-button--${state}`}
      onClick={handleClick}
      disabled={disabled}
      title={
        state === "cooldown"
          ? "Content refreshes once every 24 hours — already up to date for now"
          : "Fetch the latest sports news right now, instead of waiting for the 24-hour auto-refresh"
      }
    >
      {label}
    </button>
  );
}
