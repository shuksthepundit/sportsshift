const express = require("express");
const db = require("../db");
const { COUNTRIES, SPORTS, COUNTIES_KE, CONTINENTS } = require("../sources");

const router = express.Router();

// GET /api/news?country=KE&sport=Athletics&county=Nakuru&continent=Africa&limit=30&offset=0
router.get("/news", (req, res) => {
  const { country, sport, county, continent, limit = 30, offset = 0 } = req.query;

  const conditions = [];
  const params = {};

  if (country) {
    conditions.push("country_code = @country");
    params.country = country;
  }
  if (sport) {
    conditions.push("sport = @sport");
    params.sport = sport;
  }
  if (county) {
    conditions.push("county_code = @county");
    params.county = county;
  }
  if (continent) {
    conditions.push("continent = @continent");
    params.continent = continent;
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  params.limit = Math.min(Number(limit) || 30, 100);
  params.offset = Number(offset) || 0;

  const rows = db
    .prepare(
      `SELECT id, title, summary, url, source_name, country_code, sport, county_code, continent, image_url, published_at
       FROM articles
       ${where}
       ORDER BY COALESCE(published_at, ingested_at) DESC
       LIMIT @limit OFFSET @offset`
    )
    .all(params);

  res.json({ articles: rows, count: rows.length });
});

// GET /api/continents — every continent this app tags, with article counts. Africa
// (Kenya's continent) is listed first regardless of count, matching CONTINENTS order.
router.get("/continents", (_req, res) => {
  const counts = db
    .prepare(`SELECT continent, COUNT(*) as count FROM articles GROUP BY continent`)
    .all();
  const countMap = Object.fromEntries(counts.map((c) => [c.continent, c.count]));

  res.json(CONTINENTS.map((name) => ({ name, articleCount: countMap[name] || 0 })));
});

// GET /api/counties — Kenya's 47 counties + "National", with article counts. Mirrors
// /api/countries below but scoped to KE since counties only make sense within Kenya.
router.get("/counties", (_req, res) => {
  const counts = db
    .prepare(
      `SELECT county_code, COUNT(*) as count FROM articles WHERE country_code = 'KE' GROUP BY county_code`
    )
    .all();
  const countMap = Object.fromEntries(counts.map((c) => [c.county_code, c.count]));

  res.json([
    { code: "National", name: "National", articleCount: countMap["National"] || 0 },
    ...COUNTIES_KE.map((name) => ({ code: name, name, articleCount: countMap[name] || 0 })),
  ]);
});

// GET /api/countries — which countries are configured (and how many articles each has)
router.get("/countries", (_req, res) => {
  const counts = db
    .prepare(`SELECT country_code, COUNT(*) as count FROM articles GROUP BY country_code`)
    .all();
  const countMap = Object.fromEntries(counts.map((c) => [c.country_code, c.count]));

  res.json(
    COUNTRIES.map((c) => ({ ...c, articleCount: countMap[c.code] || 0 }))
  );
});

// GET /api/sports — which sport categories exist (and how many articles each has)
router.get("/sports", (_req, res) => {
  const counts = db
    .prepare(`SELECT sport, COUNT(*) as count FROM articles GROUP BY sport`)
    .all();
  const countMap = Object.fromEntries(counts.map((s) => [s.sport, s.count]));

  res.json(SPORTS.map((s) => ({ name: s, articleCount: countMap[s] || 0 })));
});

module.exports = router;
