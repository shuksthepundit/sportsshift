const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const DB_PATH = process.env.DB_PATH || "./data/news.db";
const resolvedPath = path.resolve(DB_PATH);
fs.mkdirSync(path.dirname(resolvedPath), { recursive: true });

const db = new Database(resolvedPath);
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    summary TEXT,
    url TEXT NOT NULL UNIQUE,
    source_name TEXT,
    country_code TEXT NOT NULL,
    sport TEXT NOT NULL,
    county_code TEXT, -- Kenyan county name (e.g. "Nakuru"), "National", or NULL for non-KE articles
    continent TEXT NOT NULL DEFAULT 'Africa', -- looked up from COUNTRIES in sources.js at ingest time
    image_url TEXT,
    published_at TEXT,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_articles_country ON articles(country_code);
  CREATE INDEX IF NOT EXISTS idx_articles_sport ON articles(sport);
  CREATE INDEX IF NOT EXISTS idx_articles_county ON articles(county_code);
  CREATE INDEX IF NOT EXISTS idx_articles_continent ON articles(continent);
  CREATE INDEX IF NOT EXISTS idx_articles_published ON articles(published_at);

  CREATE TABLE IF NOT EXISTS videos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    video_url TEXT NOT NULL UNIQUE,
    thumbnail_url TEXT,
    channel_name TEXT,
    country_code TEXT,
    sport TEXT NOT NULL,
    published_at TEXT,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_videos_country ON videos(country_code);
  CREATE INDEX IF NOT EXISTS idx_videos_sport ON videos(sport);
  CREATE INDEX IF NOT EXISTS idx_videos_published ON videos(published_at);

  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    sport TEXT NOT NULL,
    venue_name TEXT,
    venue_city TEXT,
    country_code TEXT,
    event_date TEXT,
    sponsor_name TEXT,
    ticket_url TEXT NOT NULL UNIQUE,
    image_url TEXT,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_events_country ON events(country_code);
  CREATE INDEX IF NOT EXISTS idx_events_sport ON events(sport);
  CREATE INDEX IF NOT EXISTS idx_events_date ON events(event_date);

  -- Rows move through three states: 'scheduled' (a fixture that hasn't kicked off) ->
  -- 'live' (currently being played) -> 'finished' (final score). All three share this
  -- table and are keyed by the same (home_team, away_team, match_date, sport) unique
  -- index below, so the SAME row is updated in place as a match progresses rather than
  -- creating a new row per state — a fixture upserted with status='live' overwrites the
  -- 'scheduled' row for that match, and later status='finished' overwrites that.
  -- 'live' rows are additionally wiped and replaced wholesale on every ingest run (see
  -- ingestLiveScores.js) since an in-play score is only ever a snapshot; any row that
  -- was 'live' last run and doesn't reappear as 'live' or 'finished' this run is
  -- explicitly transitioned to 'finished' there too, so a match is never stuck showing
  -- as live once it's actually over. 'finished' rows are pruned to the last day, and
  -- 'scheduled' rows are pruned once their match_date is in the past without ever
  -- having been upgraded (see pruneStaleScheduledStmt).
  CREATE TABLE IF NOT EXISTS live_matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sport TEXT NOT NULL,
    competition TEXT,
    home_team TEXT NOT NULL,
    away_team TEXT NOT NULL,
    home_score TEXT,
    away_score TEXT,
    status TEXT NOT NULL, -- 'scheduled' | 'live' | 'finished'
    match_minute TEXT,
    match_date TEXT,
    kickoff_time TEXT, -- "HH:MM" local (East Africa Time), only meaningful while 'scheduled'
    source TEXT,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE UNIQUE INDEX IF NOT EXISTS idx_live_matches_unique
    ON live_matches(home_team, away_team, match_date, sport);
  CREATE INDEX IF NOT EXISTS idx_live_matches_status ON live_matches(status);
  CREATE INDEX IF NOT EXISTS idx_live_matches_date ON live_matches(match_date);

  CREATE TABLE IF NOT EXISTS daily_digest (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    headline TEXT NOT NULL,
    summary TEXT,
    sport TEXT,
    country_code TEXT,
    source_url TEXT UNIQUE,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_daily_digest_ingested ON daily_digest(ingested_at);

  -- One row per calendar day (published_date is UNIQUE), holding a full AI-written
  -- roundup article synthesized from what's already in the other tables that day.
  CREATE TABLE IF NOT EXISTS daily_articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    summary TEXT,
    published_date TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_daily_articles_date ON daily_articles(published_date);

  -- One row per SOURCE ITEM (a digest headline or a finished match), not per day —
  -- unlike daily_articles above. source_ref is a stable key for the originating item
  -- (the headline's URL, or a team/date/sport key for a match) so the same item never
  -- gets turned into a duplicate article across ingestion runs.
  CREATE TABLE IF NOT EXISTS auto_articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_type TEXT NOT NULL, -- 'digest' | 'result'
    source_ref TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    summary TEXT,
    sport TEXT,
    country_code TEXT,
    published_date TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE UNIQUE INDEX IF NOT EXISTS idx_auto_articles_source ON auto_articles(source_type, source_ref);
  CREATE INDEX IF NOT EXISTS idx_auto_articles_date ON auto_articles(published_date);

  -- Tracks development progress/gaps/opportunities/missed opportunities affecting the
  -- welfare of sportsmen and women — funding, facilities, legislation implementation
  -- (e.g. the Sports Act 2013, National Sports Fund), anti-doping, gender equity, referee
  -- welfare, etc. Populated by welfareSearch.js's web-search-grounded Claude calls (see
  -- ingestWelfareReports.js) and intended as AI-drafted material for editorial review,
  -- not auto-published as verified fact — see README for the human-review note.
  CREATE TABLE IF NOT EXISTS welfare_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,       -- one of WELFARE_CATEGORIES in sources.js
    status TEXT NOT NULL,         -- 'progress' | 'gap' | 'opportunity' | 'missed_opportunity'
    title TEXT NOT NULL,
    summary TEXT,
    sport TEXT,
    county_code TEXT,             -- Kenyan county name, "National", or NULL for foreign items
    country_code TEXT,            -- ISO alpha-2; lets this table also hold foreign comparisons
    source_url TEXT UNIQUE,
    reviewed INTEGER NOT NULL DEFAULT 0, -- 0 = AI-drafted, unreviewed; 1 = editor-confirmed
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_welfare_category ON welfare_reports(category);
  CREATE INDEX IF NOT EXISTS idx_welfare_status ON welfare_reports(status);
  CREATE INDEX IF NOT EXISTS idx_welfare_county ON welfare_reports(county_code);

  -- Small key/value store for app-wide bookkeeping that doesn't belong to any one
  -- content table — currently just the timestamp of the last full ingest run, used to
  -- gate the manual "Refresh now" button to once per 24 hours (see server.js's
  -- POST /api/ingest and GET /api/ingest/status).
  CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

// Lightweight migration for DBs created before county_code existed on articles —
// CREATE TABLE IF NOT EXISTS above only applies to brand-new databases, so an existing
// data/news.db from before this change needs the column added explicitly.
const articleColumns = db.prepare(`PRAGMA table_info(articles)`).all();
if (!articleColumns.some((col) => col.name === "county_code")) {
  db.exec(`ALTER TABLE articles ADD COLUMN county_code TEXT`);
  db.exec(`CREATE INDEX IF NOT EXISTS idx_articles_county ON articles(county_code)`);
}
// Same idea for continent, added when global (beyond-Africa) coverage was introduced.
if (!articleColumns.some((col) => col.name === "continent")) {
  db.exec(`ALTER TABLE articles ADD COLUMN continent TEXT NOT NULL DEFAULT 'Africa'`);
  db.exec(`CREATE INDEX IF NOT EXISTS idx_articles_continent ON articles(continent)`);
}
// Same idea for live_matches.kickoff_time, added when fixture ('scheduled') tracking
// was introduced — existing DBs created before this change won't have the column yet.
const liveMatchColumns = db.prepare(`PRAGMA table_info(live_matches)`).all();
if (!liveMatchColumns.some((col) => col.name === "kickoff_time")) {
  db.exec(`ALTER TABLE live_matches ADD COLUMN kickoff_time TEXT`);
}

module.exports = db;
