const { searchForJSON } = require("./aiSearch");

const LIVE_SCORES_PROMPT = `Search flashscore.com and other reliable live sports score sites for the CURRENT state of sports scores AND upcoming kickoffs, with priority on Kenyan and African football/athletics/rugby but also covering major global fixtures (Premier League, Champions League, etc).

Return ONLY a single JSON object, no prose, no markdown fences, with exactly this shape:
{
  "fixtures": [
    {
      "sport": "Football",
      "competition": "Kenyan Premier League",
      "homeTeam": "Gor Mahia",
      "awayTeam": "AFC Leopards",
      "matchDate": "2026-07-15",
      "kickoffTime": "15:00"
    }
  ],
  "live": [
    {
      "sport": "Football",
      "competition": "Kenyan Premier League",
      "homeTeam": "Gor Mahia",
      "awayTeam": "AFC Leopards",
      "homeScore": "1",
      "awayScore": "0",
      "minute": "63'",
      "matchDate": "2026-07-14"
    }
  ],
  "results": [
    {
      "sport": "Football",
      "competition": "Kenyan Premier League",
      "homeTeam": "Tusker FC",
      "awayTeam": "Kakamega Homeboyz",
      "homeScore": "2",
      "awayScore": "1",
      "matchDate": "2026-07-14"
    }
  ]
}

STRICT rules:
- "fixtures" must ONLY contain matches scheduled to kick off later TODAY or in the next 48 hours that have NOT started yet — never matches already in progress or finished.
- "live" must ONLY contain matches that are actually in progress right now (currently being played) — never fixtures that haven't kicked off, and never finished matches. Always include matchDate (today's date, ISO) so a live match can be matched back to its fixture entry.
- "results" must ONLY contain matches that finished earlier TODAY or YESTERDAY (in East Africa Time) — never anything older.
- If you can't confirm a match's real-time status, leave it out rather than guessing.
- matchDate must be an ISO date (YYYY-MM-DD). kickoffTime, when known, should be 24h "HH:MM" local (East Africa Time) — omit it if unknown rather than guessing.
- If there are genuinely no fixtures, no live matches, or no recent results right now, return an empty array for that field — do not invent matches.`;

async function fetchLiveAndResults() {
  const data = await searchForJSON(LIVE_SCORES_PROMPT, { maxTokens: 3500 });
  if (!data) return { fixtures: [], live: [], results: [] };
  return {
    fixtures: Array.isArray(data.fixtures) ? data.fixtures : [],
    live: Array.isArray(data.live) ? data.live : [],
    results: Array.isArray(data.results) ? data.results : [],
  };
}

module.exports = { fetchLiveAndResults };
