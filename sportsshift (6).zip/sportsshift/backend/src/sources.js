// Feed sources to ingest, grouped by country.
//
// IMPORTANT: news sites change their RSS paths often (some drop RSS entirely when they
// redesign). Treat this list as a starting point, not a guarantee — before your first real
// ingest run, open each `feedUrl` in a browser and confirm it returns XML, not a 404/HTML
// page. Most WordPress-based sites (Capital FM, KBC, The Star) expose a feed at
// `<section-url>/feed/`. Sites built on custom CMSs (Nation.Africa, Standard) sometimes
// publish a dedicated RSS index instead — check standardmedia.co.ke/rssfeeds for the
// current list of Standard Group feeds.
//
// country_code follows ISO 3166-1 alpha-2. Add a new country by adding entries here —
// nothing else in the pipeline needs to change.

// sourceType distinguishes the kind of voice behind a feed — used for filtering/display
// and so the frontend can label an item "Analysis" or "Commentary" rather than presenting
// an individual's opinion as if it were a newsroom report. One of:
//   "news"        — a newsroom/outlet's sports desk
//   "blog"        — an independent Kenyan sports blog
//   "analyst"     — a named sports analyst's own site/column feed
//   "commentator" — a commentator's own site/column feed
//   "referee"     — official statements/feeds from a referees' association or body
const SOURCES = [
  {
    countryCode: "KE",
    sourceType: "news",
    name: "Capital Sports",
    feedUrl: "https://www.capitalfm.co.ke/sports/feed/",
  },
  {
    countryCode: "KE",
    sourceType: "news",
    name: "The Star Kenya - Sports",
    feedUrl: "https://www.the-star.co.ke/sports/rss",
  },
  {
    countryCode: "KE",
    sourceType: "news",
    name: "KBC Sports",
    feedUrl: "https://www.kbc.co.ke/category/sports/feed/",
  },
  {
    countryCode: "KE",
    sourceType: "news",
    name: "Standard Sports",
    // Confirm the exact sports-section path at https://www.standardmedia.co.ke/rssfeeds
    feedUrl: "https://www.standardmedia.co.ke/rss/sports.php",
  },
  {
    countryCode: "KE",
    sourceType: "news",
    name: "Nation Sport",
    feedUrl: "https://nation.africa/kenya/sports/rss",
  },
  {
    countryCode: "KE",
    sourceType: "news",
    name: "Pulse Sports Kenya",
    feedUrl: "https://www.pulsesports.co.ke/rss",
  },
  // --- Rest of Africa — real feeds where a stable one is publicly known ------------------
  {
    countryCode: "NG",
    sourceType: "news",
    name: "Complete Sports Nigeria",
    feedUrl: "https://www.completesports.com/feed/",
  },
  {
    countryCode: "ZA",
    sourceType: "news",
    name: "News24 Sport (South Africa)",
    feedUrl: "https://feeds.24.com/articles/sport24/allsport/rss",
  },
  {
    countryCode: "GH",
    sourceType: "news",
    name: "GhanaWeb Sports",
    feedUrl: "https://www.ghanaweb.com/GhanaHomePage/SportsArchive/rss.xml",
  },
  // EG, ET, TZ, UG, MA, SN, CI, CM have no verified feed yet — add the same way as
  // above once you've confirmed a real RSS URL for that country's sports coverage.
  //
  // --- Rest of the world — one flagship market per continent to start; add more the
  // same way (see "Adding a new country" in README.md). ----------------------------------
  {
    countryCode: "IN",
    sourceType: "news",
    name: "The Hindu Sport (India)",
    feedUrl: "https://www.thehindu.com/sport/feeder/default.rss",
  },
  {
    countryCode: "GB",
    sourceType: "news",
    name: "BBC Sport (UK)",
    feedUrl: "http://feeds.bbci.co.uk/sport/rss.xml",
  },
  {
    countryCode: "US",
    sourceType: "news",
    name: "ESPN (USA)",
    feedUrl: "https://www.espn.com/espn/rss/news",
  },
  {
    countryCode: "BR",
    sourceType: "news",
    name: "ge.globo (Brazil)",
    feedUrl: "https://ge.globo.com/rss/ge/",
  },
  {
    countryCode: "AU",
    sourceType: "news",
    name: "ABC Sport (Australia)",
    feedUrl: "https://www.abc.net.au/news/feed/45910/rss.xml",
  },
  // --- Blogs / analysts / commentators / referee bodies -------------------------------
  // These voices matter for legislation-implementation and welfare coverage but most
  // don't run a CMS with a reliable feed the way newsrooms do. Add real ones here as you
  // find them (verify the feed URL first, same as any source above); until then this
  // list is intentionally short and honest rather than padded with guessed URLs.
  {
    countryCode: "KE",
    sourceType: "blog",
    name: "Kenyan sports blogs (add feeds as found)",
    feedUrl: null, // placeholder — fill in once you've verified a specific blog's feed
  },
  {
    countryCode: "KE",
    sourceType: "referee",
    name: "Kenya Referees Association (add feed/RSS if published)",
    feedUrl: null, // most federation bodies publish updates as web pages, not RSS —
    // consider a small dedicated scraper for this one page if it never gets a feed
  },
];

// Every continent this app tags articles with. Africa comes first — Kenya is the anchor
// market — followed by the order the rest of COUNTRIES below introduces them in.
const CONTINENTS = ["Africa", "Asia", "Europe", "North America", "South America", "Oceania"];

// Ordered Kenya-first, then other African countries, then one flagship market per
// remaining continent (Asia, Europe, North America, South America, Oceania) so the app
// has real, working coverage on every continent from day one. Ticketmaster's Discovery
// API doesn't have event inventory in every one of these countries yet — ingestEvents.js
// just logs 0 results and moves on when that happens, it doesn't fail the run.
const COUNTRIES = [
  { code: "KE", name: "Kenya", flag: "\uD83C\uDDF0\uD83C\uDDEA", continent: "Africa" },
  { code: "NG", name: "Nigeria", flag: "\uD83C\uDDF3\uD83C\uDDEC", continent: "Africa" },
  { code: "ZA", name: "South Africa", flag: "\uD83C\uDDFF\uD83C\uDDE6", continent: "Africa" },
  { code: "GH", name: "Ghana", flag: "\uD83C\uDDEC\uD83C\uDDED", continent: "Africa" },
  { code: "EG", name: "Egypt", flag: "\uD83C\uDDEA\uD83C\uDDEC", continent: "Africa" },
  { code: "ET", name: "Ethiopia", flag: "\uD83C\uDDEA\uD83C\uDDF9", continent: "Africa" },
  { code: "TZ", name: "Tanzania", flag: "\uD83C\uDDF9\uD83C\uDDFF", continent: "Africa" },
  { code: "UG", name: "Uganda", flag: "\uD83C\uDDFA\uD83C\uDDEC", continent: "Africa" },
  { code: "MA", name: "Morocco", flag: "\uD83C\uDDF2\uD83C\uDDE6", continent: "Africa" },
  { code: "SN", name: "Senegal", flag: "\uD83C\uDDF8\uD83C\uDDF3", continent: "Africa" },
  { code: "CI", name: "Ivory Coast", flag: "\uD83C\uDDE8\uD83C\uDDEE", continent: "Africa" },
  { code: "CM", name: "Cameroon", flag: "\uD83C\uDDE8\uD83C\uDDF2", continent: "Africa" },
  { code: "IN", name: "India", flag: "\uD83C\uDDEE\uD83C\uDDF3", continent: "Asia" },
  { code: "GB", name: "United Kingdom", flag: "\uD83C\uDDEC\uD83C\uDDE7", continent: "Europe" },
  { code: "US", name: "United States", flag: "\uD83C\uDDFA\uD83C\uDDF8", continent: "North America" },
  { code: "BR", name: "Brazil", flag: "\uD83C\uDDE7\uD83C\uDDF7", continent: "South America" },
  { code: "AU", name: "Australia", flag: "\uD83C\uDDE6\uD83C\uDDFA", continent: "Oceania" },
  // Add more countries here the same way as you expand further —
  // { code: "DE", name: "Germany", flag: "🇩🇪", continent: "Europe" }, etc.
];

// Looks up a country's continent for tagging articles at ingest time. Falls back to
// "Africa" for an unrecognized code rather than leaving it blank, since Kenya/Africa is
// this app's home base and most misclassified codes will be near neighbors.
function continentForCountry(countryCode) {
  const match = COUNTRIES.find((c) => c.code === countryCode);
  return match ? match.continent : "Africa";
}

// All 47 Kenyan counties, for tagging KE articles by where the story is actually about
// (a county sports ground, a county assembly sports budget line, a county athletics meet,
// etc). classifyArticle() in claude.js matches against this list; "National" covers
// stories about Kenya as a whole rather than one county.
const COUNTIES_KE = [
  "Mombasa", "Kwale", "Kilifi", "Tana River", "Lamu", "Taita Taveta", "Garissa",
  "Wajir", "Mandera", "Marsabit", "Isiolo", "Meru", "Tharaka-Nithi", "Embu",
  "Kitui", "Machakos", "Makueni", "Nyandarua", "Nyeri", "Kirinyaga",
  "Murang'a", "Kiambu", "Turkana", "West Pokot", "Samburu", "Trans Nzoia",
  "Uasin Gishu", "Elgeyo-Marakwet", "Nandi", "Baringo", "Laikipia", "Nakuru",
  "Narok", "Kajiado", "Kericho", "Bomet", "Kakamega", "Vihiga", "Bungoma",
  "Busia", "Siaya", "Kisumu", "Homa Bay", "Migori", "Kisii", "Nyamira",
  "Nairobi",
];

// Categories for the welfare/development tracker (welfare_reports table). Each entry
// stored there is tagged with one of these plus a status of progress / gap / opportunity
// / missed_opportunity — see welfareSearch.js and ingestWelfareReports.js.
const WELFARE_CATEGORIES = [
  "Athlete Welfare & Pay",
  "Facilities & Infrastructure",
  "Grassroots & Talent Development",
  "Sports Legislation & Governance",
  "Anti-Doping & Integrity",
  "Gender Equity in Sport",
  "Referee & Match Official Welfare",
  "Funding & Sponsorship",
];

// Search terms used for YouTube ingestion, per country. Kept generic (name + sport
// keywords) so adding a country to COUNTRIES above is enough for RSS + events; add an
// entry here too if you want more targeted YouTube queries for that country (e.g. a
// specific league or national team name pulls better results than the generic form).
const YOUTUBE_QUERIES_BY_COUNTRY = {
  KE: ["Kenya sports highlights", "Harambee Stars", "Kenya athletics"],
  NG: ["Nigeria sports highlights", "Super Eagles"],
  ZA: ["South Africa sports highlights", "Bafana Bafana", "Springboks"],
  GH: ["Ghana sports highlights", "Black Stars"],
  EG: ["Egypt sports highlights", "Pharaohs football"],
  ET: ["Ethiopia sports highlights", "Ethiopia athletics"],
  TZ: ["Tanzania sports highlights", "Taifa Stars"],
  UG: ["Uganda sports highlights", "Cranes football"],
  MA: ["Morocco sports highlights", "Atlas Lions"],
  SN: ["Senegal sports highlights", "Lions of Teranga"],
  CI: ["Ivory Coast sports highlights", "Elephants football"],
  CM: ["Cameroon sports highlights", "Indomitable Lions"],
};

// Queries with no single-country focus — global tournaments, awards, sponsor news.
const GLOBAL_YOUTUBE_QUERIES = [
  "World Cup highlights",
  "Olympics highlights",
  "Champions League highlights",
  "African Cup of Nations highlights",
  "sports awards ceremony",
];

const SPORTS = [
  "Football",
  "Athletics",
  "Rugby",
  "Volleyball",
  "Basketball",
  "Boxing",
  "Cricket",
  "Motorsport",
  "Golf",
  "Sports Legislation & Governance",
  "Other",
];

// Social platforms this app could pull from, IF you supply your own developer
// credentials. Disabled by default. Facebook, X/Twitter, Instagram, and TikTok all
// prohibit scraping outside their official APIs in their Terms of Service — that's why
// there's no scraper for them here. Get API access, set enabled: true, and implement the
// platform's documented search/timeline call in a new ingestSocial.js that follows the
// same insert-into-articles pattern as ingest.js.
const SOCIAL_SOURCES = {
  twitter_x: { enabled: false, bearerToken: process.env.X_BEARER_TOKEN || "" },
  facebook: { enabled: false, accessToken: process.env.FB_ACCESS_TOKEN || "" },
};

module.exports = {
  SOURCES,
  COUNTRIES,
  CONTINENTS,
  continentForCountry,
  COUNTIES_KE,
  WELFARE_CATEGORIES,
  SPORTS,
  SOCIAL_SOURCES,
  YOUTUBE_QUERIES_BY_COUNTRY,
  GLOBAL_YOUTUBE_QUERIES,
};
