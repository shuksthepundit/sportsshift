// Tiny helper around the app_meta key/value table (see db.js). Used to remember
// timestamps that need to survive server restarts — currently just "when did the last
// full content refresh happen", which gates the manual Refresh button to once per
// 24 hours (see server.js).
const db = require("./db");

const getStmt = db.prepare(`SELECT value FROM app_meta WHERE key = ?`);
const setStmt = db.prepare(`
  INSERT INTO app_meta (key, value) VALUES (?, ?)
  ON CONFLICT(key) DO UPDATE SET value = excluded.value
`);

function getMeta(key) {
  const row = getStmt.get(key);
  return row ? row.value : null;
}

function setMeta(key, value) {
  setStmt.run(key, String(value));
}

module.exports = { getMeta, setMeta };
