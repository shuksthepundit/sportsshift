require("dotenv").config();
const db = require("./db");
const { fetchLiveAndResults } = require("./liveScoresSearch");

const upsertStmt = db.prepare(`
  INSERT INTO live_matches
    (sport, competition, home_team, away_team, home_score, away_score, status, match_minute, match_date, kickoff_time, source, updated_at)
  VALUES
    (@sport, @competition, @home_team, @away_team, @home_score, @away_score, @status, @match_minute, @match_date, @kickoff_time, @source, datetime('now'))
  ON CONFLICT(home_team, away_team, match_date, sport) DO UPDATE SET
    competition = excluded.competition,
    home_score = excluded.home_score,
    away_score = excluded.away_score,
    status = excluded.status,
    match_minute = excluded.match_minute,
    kickoff_time = excluded.kickoff_time,
    updated_at = datetime('now')
`);

// Rows that were 'live' as of the previous ingest run, fetched BEFORE this run's
// snapshot is written — used below to detect matches that have ended between runs.
const previousLiveStmt = db.prepare(
  `SELECT id, sport, home_team, away_team, match_date FROM live_matches WHERE status = 'live'`
);

// A match found live last run and NOT present in this run's fresh 'live' or 'results'
// set has, by elimination, finished in between — flip it to 'finished' explicitly
// instead of leaving it live or silently deleting it, so it still shows up once under
// "Results" rather than just vanishing.
const markFinishedStmt = db.prepare(
  `UPDATE live_matches SET status = 'finished', match_minute = NULL, updated_at = datetime('now') WHERE id = ?`
);

// Safety net beyond the prompt's own instructions: finished results older than 1 day
// never linger in the table even if something upstream misbehaves.
const pruneOldResultsStmt = db.prepare(`
  DELETE FROM live_matches WHERE status = 'finished' AND match_date < date('now', '-1 day')
`);

// A fixture that was scheduled for a past date and never got upgraded to 'live' or
// 'finished' (postponement, bad source data, etc.) shouldn't linger indefinitely either.
const pruneStaleScheduledStmt = db.prepare(`
  DELETE FROM live_matches WHERE status = 'scheduled' AND match_date < date('now')
`);

function matchKey(m) {
  return `${m.sport}|${m.home_team}|${m.away_team}|${m.match_date}`;
}

async function ingestLiveScores() {
  console.log("Starting live scores ingestion run...");
  const { fixtures, live, results } = await fetchLiveAndResults();

  // Snapshot of what was live going into this run, so we can tell afterwards which of
  // those matches simply didn't come back (i.e. they've ended) — see below.
  const previousLive = previousLiveStmt.all();

  let fixturesAdded = 0;
  for (const match of fixtures) {
    if (!match.homeTeam || !match.awayTeam || !match.matchDate) continue;
    upsertStmt.run({
      sport: match.sport || "Other",
      competition: match.competition || null,
      home_team: match.homeTeam,
      away_team: match.awayTeam,
      home_score: null,
      away_score: null,
      status: "scheduled",
      match_minute: null,
      match_date: match.matchDate,
      kickoff_time: match.kickoffTime || null,
      source: "AI search (flashscore + web)",
    });
    fixturesAdded++;
  }

  const liveKeys = new Set();
  let liveAdded = 0;
  for (const match of live) {
    if (!match.homeTeam || !match.awayTeam) continue;
    const match_date = match.matchDate || new Date().toISOString().slice(0, 10);
    upsertStmt.run({
      sport: match.sport || "Other",
      competition: match.competition || null,
      home_team: match.homeTeam,
      away_team: match.awayTeam,
      home_score: match.homeScore ?? null,
      away_score: match.awayScore ?? null,
      status: "live",
      match_minute: match.minute || null,
      match_date,
      kickoff_time: null,
      source: "AI search (flashscore + web)",
    });
    liveKeys.add(matchKey({ sport: match.sport || "Other", home_team: match.homeTeam, away_team: match.awayTeam, match_date }));
    liveAdded++;
  }

  const resultKeys = new Set();
  let resultsAdded = 0;
  for (const match of results) {
    if (!match.homeTeam || !match.awayTeam || !match.matchDate) continue;
    upsertStmt.run({
      sport: match.sport || "Other",
      competition: match.competition || null,
      home_team: match.homeTeam,
      away_team: match.awayTeam,
      home_score: match.homeScore ?? null,
      away_score: match.awayScore ?? null,
      status: "finished",
      match_minute: null,
      match_date: match.matchDate,
      kickoff_time: null,
      source: "AI search (flashscore + web)",
    });
    resultKeys.add(matchKey({ sport: match.sport || "Other", home_team: match.homeTeam, away_team: match.awayTeam, match_date: match.matchDate }));
    resultsAdded++;
  }

  // The actual "live -> finished" transition: any match that was live last run but is
  // in neither this run's live set nor its results set has finished without the AI
  // search explicitly reporting a final score for it. Rather than leave a stale "LIVE"
  // match on screen forever, flip it to finished now; a later run will pick up the
  // real final score via "results" and overwrite it (upsert is keyed on the same row).
  let autoFinished = 0;
  for (const row of previousLive) {
    const key = matchKey(row);
    if (!liveKeys.has(key) && !resultKeys.has(key)) {
      markFinishedStmt.run(row.id);
      autoFinished++;
    }
  }

  pruneOldResultsStmt.run();
  pruneStaleScheduledStmt.run();

  console.log(
    `Live scores ingestion complete. ${fixturesAdded} fixture(s), ${liveAdded} live match(es), ${resultsAdded} explicit result(s), ${autoFinished} match(es) auto-transitioned to finished.`
  );
  return { fixturesAdded, liveAdded, resultsAdded, autoFinished };
}

if (require.main === module) {
  ingestLiveScores()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Live scores ingestion run failed:", err);
      process.exit(1);
    });
}

module.exports = { ingestLiveScores };
