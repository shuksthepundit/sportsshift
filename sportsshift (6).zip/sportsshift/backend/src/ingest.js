require("dotenv").config();
const Parser = require("rss-parser");
const db = require("./db");
const { SOURCES, continentForCountry } = require("./sources");
const { classifyArticle } = require("./claude");

const parser = new Parser({ timeout: 15000 });

const insertStmt = db.prepare(`
  INSERT OR IGNORE INTO articles
    (title, summary, url, source_name, country_code, sport, county_code, continent, image_url, published_at)
  VALUES
    (@title, @summary, @url, @source_name, @country_code, @sport, @county_code, @continent, @image_url, @published_at)
`);

const existsStmt = db.prepare(`SELECT 1 FROM articles WHERE url = ?`);

function extractImage(item) {
  if (item.enclosure && item.enclosure.url) return item.enclosure.url;
  const match = (item["content:encoded"] || item.content || "").match(
    /<img[^>]+src="([^">]+)"/
  );
  return match ? match[1] : null;
}

// Fallback only — used when classifyArticle() couldn't produce its own one-sentence
// summary (e.g. the Claude call failed). Keeps the raw feed snippet from ballooning
// past what a "brief summary" should be: whole sentences up to ~220 chars.
function briefFallback(snippet) {
  const text = (snippet || "").trim();
  if (!text) return null;
  const sentences = text.split(/(?<=[.!?])\s+/);
  let out = "";
  for (const s of sentences) {
    const candidate = out ? `${out} ${s}` : s;
    if (candidate.length > 220) break;
    out = candidate;
  }
  if (!out) out = text.slice(0, 220).split(" ").slice(0, -1).join(" ");
  return /[.!?]$/.test(out) ? out : `${out}…`;
}

async function ingestSource(source) {
  if (!source.feedUrl) {
    // Placeholder entry (see sources.js) — nothing to fetch yet, not a failure.
    console.log(`[${source.name}] no feed URL configured yet — skipping.`);
    return { source: source.name, added: 0, skipped: 0, failed: false };
  }

  let feed;
  try {
    feed = await parser.parseURL(source.feedUrl);
  } catch (err) {
    console.error(`[${source.name}] failed to fetch feed: ${err.message}`);
    return { source: source.name, added: 0, skipped: 0, failed: true };
  }

  let added = 0;
  let skipped = 0;

  for (const item of feed.items || []) {
    const url = item.link;
    if (!url || existsStmt.get(url)) {
      skipped++;
      continue;
    }

    const snippet = (item.contentSnippet || item.summary || "").slice(0, 500);
    const { sport, countryCode, countyCode, summary } = await classifyArticle({
      title: item.title,
      snippet,
      defaultCountryCode: source.countryCode,
    });

    insertStmt.run({
      title: item.title,
      summary: summary || briefFallback(snippet),
      url,
      source_name: source.name,
      country_code: countryCode,
      sport,
      county_code: countyCode,
      continent: continentForCountry(countryCode),
      image_url: extractImage(item),
      published_at: item.isoDate || item.pubDate || null,
    });
    added++;
  }

  console.log(`[${source.name}] added ${added}, skipped ${skipped} (already had them)`);
  return { source: source.name, added, skipped, failed: false };
}

async function ingestAll() {
  console.log(`Starting ingestion run for ${SOURCES.length} source(s)...`);
  const results = [];
  for (const source of SOURCES) {
    results.push(await ingestSource(source));
  }
  const totalAdded = results.reduce((sum, r) => sum + r.added, 0);
  console.log(`Ingestion run complete. ${totalAdded} new article(s) added.`);
  return results;
}

// Allow `node src/ingest.js` to run a one-off ingestion
if (require.main === module) {
  ingestAll()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Ingestion run failed:", err);
      process.exit(1);
    });
}

module.exports = { ingestAll };
