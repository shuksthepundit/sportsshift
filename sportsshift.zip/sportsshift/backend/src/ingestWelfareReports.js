require("dotenv").config();
const db = require("./db");
const { fetchWelfareReports } = require("./welfareSearch");

const insertStmt = db.prepare(`
  INSERT OR IGNORE INTO welfare_reports
    (category, status, title, summary, sport, county_code, country_code, source_url)
  VALUES
    (@category, @status, @title, @summary, @sport, @county_code, @country_code, @source_url)
`);

const VALID_STATUSES = new Set(["progress", "gap", "opportunity", "missed_opportunity"]);

async function ingestWelfareReports() {
  console.log("Starting welfare/development tracker ingestion run...");
  const items = await fetchWelfareReports();

  let added = 0;
  for (const item of items) {
    if (!item.title || !item.url || !item.category) continue;
    if (!VALID_STATUSES.has(item.status)) continue;

    insertStmt.run({
      category: item.category,
      status: item.status,
      title: item.title,
      summary: item.summary || null,
      sport: item.sport || null,
      county_code: item.county || null,
      country_code: item.country_code || null,
      source_url: item.url,
    });
    added++;
  }

  console.log(
    `Welfare tracker ingestion complete. ${added} new item(s) added (unreviewed — see README on human review).`
  );
  return { added };
}

if (require.main === module) {
  ingestWelfareReports()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Welfare tracker ingestion run failed:", err);
      process.exit(1);
    });
}

module.exports = { ingestWelfareReports };
