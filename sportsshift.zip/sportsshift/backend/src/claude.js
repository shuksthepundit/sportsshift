const Anthropic = require("@anthropic-ai/sdk");
const { SPORTS, COUNTRIES, COUNTIES_KE } = require("./sources");

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SPORT_LIST = SPORTS.join(", ");
const COUNTRY_LIST = COUNTRIES.map((c) => `${c.code} (${c.name})`).join(", ");
const COUNTY_LIST = COUNTIES_KE.join(", ");

/**
 * Classify a single article: which sport it's about, which country it's primarily about,
 * which Kenyan county it's about (if any), and a short neutral one-paragraph summary.
 * Falls back to the feed's own country/"Other" sport/no county if the API call fails, so
 * ingestion never blocks on a single bad classification.
 */
async function classifyArticle({ title, snippet, defaultCountryCode }) {
  const prompt = `You are tagging a sports news headline for a news app. Respond with ONLY a JSON object, no other text, no markdown fences.

Headline: ${title}
Snippet: ${snippet || "(none provided)"}

Return JSON with exactly these fields:
{
  "sport": one of [${SPORT_LIST}],
  "country_code": the ISO country code this article is mainly about, preferring one of [${COUNTRY_LIST}] when it applies, otherwise your best-guess ISO alpha-2 code,
  "county": if country_code is "KE" AND the story is clearly about a specific place, one of [${COUNTY_LIST}]; if it's about Kenya nationally use "National"; if country_code is not "KE" use null,
  "summary": a neutral, one-sentence (under 30 words) summary in your own words
}`;

  try {
    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 300,
      messages: [{ role: "user", content: prompt }],
    });

    const text = response.content
      .map((block) => (block.type === "text" ? block.text : ""))
      .join("")
      .trim()
      .replace(/^```json\s*|```$/g, "");

    const parsed = JSON.parse(text);
    const countryCode = parsed.country_code || defaultCountryCode;
    return {
      sport: SPORTS.includes(parsed.sport) ? parsed.sport : "Other",
      countryCode,
      countyCode: countryCode === "KE" ? parsed.county || "National" : null,
      summary: parsed.summary || null,
    };
  } catch (err) {
    console.error(`Classification failed for "${title}":`, err.message);
    return {
      sport: "Other",
      countryCode: defaultCountryCode,
      countyCode: defaultCountryCode === "KE" ? "National" : null,
      summary: null,
    };
  }
}

module.exports = { classifyArticle };
