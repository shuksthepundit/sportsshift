// Sources material for the welfare/development tracker: progress, gaps, opportunities,
// and missed opportunities affecting the welfare of sportsmen and women in Kenya (and,
// for comparison, in other countries). Follows the same searchForJSON pattern as
// dailyDigestSearch.js — see aiSearch.js for why this uses Claude's web search tool
// rather than a bespoke scraper.
//
// IMPORTANT — human review matters more here than for ordinary headlines: claims about
// welfare failures can name specific federations, counties, or officials. Every row this
// writes goes into welfare_reports with reviewed = 0 (see db.js) and should be checked
// by an editor against the cited source_url before being presented as confirmed fact,
// not just AI-summarized search results.

const { searchForJSON } = require("./aiSearch");
const { WELFARE_CATEGORIES, COUNTIES_KE } = require("./sources");

const CATEGORY_LIST = WELFARE_CATEGORIES.join(", ");
const COUNTY_LIST = COUNTIES_KE.join(", ");

const WELFARE_PROMPT = `Search the web for recent, credible reporting (last ~7 days where possible) on the welfare and development of sportsmen and women — with priority on Kenya, and a few notable foreign comparisons for context. Look across news coverage, sports federation statements, county government sports budgets, and implementation of Kenyan sports legislation (e.g. the Sports Act 2013, National Sports Fund, Sports Registrar's office).

Cover things like: athlete pay/allowances disputes, training facility conditions, grassroots/talent pipeline investment, how sports legislation is or isn't being implemented, anti-doping enforcement, gender equity in pay/opportunity, referee and match official welfare (pay, training, safety), and sponsorship/funding gaps.

Return ONLY a JSON array, no prose, no markdown fences, of up to 10 items in exactly this shape:
[
  {
    "category": one of [${CATEGORY_LIST}],
    "status": one of ["progress", "gap", "opportunity", "missed_opportunity"],
    "title": "Short, neutral headline in your own words, under 15 words",
    "summary": "Two or three neutral sentences of context in your own words — never copy text verbatim from a source",
    "sport": "the sport this concerns, or 'Cross-sport' if general",
    "country_code": "ISO alpha-2 code",
    "county": if country_code is "KE" and a specific place is named, one of [${COUNTY_LIST}], otherwise "National" for KE or null for other countries,
    "url": "https://the-real-source-url-you-found.example.com"
  }
]

Rules:
- title and summary must be original phrasing, not copied sentences from any source.
- Use "progress" for a genuine improvement, "gap" for an ongoing unmet need, "opportunity" for something actionable but not yet pursued, "missed_opportunity" for something that was available but wasn't taken up (a lapsed grant, an unused facility, a deadline missed).
- url must be a real URL you found via search — never invent one.
- Stay factual and attribute claims to what the source reported; do not editorialize or take a side on any dispute.`;

async function fetchWelfareReports() {
  const data = await searchForJSON(WELFARE_PROMPT, { maxTokens: 3000 });
  return Array.isArray(data) ? data : [];
}

module.exports = { fetchWelfareReports };
