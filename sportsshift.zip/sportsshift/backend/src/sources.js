// Feed sources to ingest, grouped by country.
//
// IMPORTANT: news sites change their RSS paths often (some drop RSS entirely when they
// redesign). Treat this list as a starting point, not a guarantee — before your first real
// ingest run, open each `feedUrl` in a browser and confirm it returns XML, not a 404/HTML
// page. Most WordPress-based sites (Capital FM, KBC, The Star) expose a feed at
// `<section-url>/feed/`. Sites built on custom CMSs (Nation.Africa, Standard) sometimes
// publish a dedicated RSS index instead — check standardmedia.co.ke/rssfeeds for the
// current list of Standard Group feeds.
//
// country_code follows ISO 3166-1 alpha-2. Add a new country by adding entries here —
// nothing else in the pipeline needs to change.

// sourceType distinguishes the kind of voice behind a feed — used for filtering/display
// and so the frontend can label an item "Analysis" or "Commentary" rather than presenting
// an individual's opinion as if it were a newsroom report. One of:
//   "news"        — a newsroom/outlet's sports desk
//   "blog"        — an independent Kenyan sports blog
//   "analyst"     — a named sports analyst's own site/column feed
//   "commentator" — a commentator's own site/column feed
//   "referee"     — official statements/feeds from a referees' association or body
const SOURCES = [
  {
    countryCode: "KE",
    sourceType: "news",
    name: "Capital Sports",
    feedUrl: "https://www.capitalfm.co.ke/sports/feed/",
  },
  {
    countryCode: "KE",
    sourceType: "news",
    name: "The Star Kenya - Sports",
    feedUrl: "https://www.the-star.co.ke/sports/rss",
  },
  {
    countryCode: "KE",
    sourceType: "news",
    name: "KBC Sports",
    feedUrl: "https://www.kbc.co.ke/category/sports/feed/",
  },
  {
    countryCode: "KE",
    sourceType: "news",
    name: "Standard Sports",
    // Confirm the exact sports-section path at https://www.standardmedia.co.ke/rssfeeds
    feedUrl: "https://www.standardmedia.co.ke/rss/sports.php",
  },
  {
    countryCode: "KE",
    sourceType: "news",
    name: "Nation Sport",
    feedUrl: "https://nation.africa/kenya/sports/rss",
  },
  {
    countryCode: "KE",
    sourceType: "news",
    name: "Pulse Sports Kenya",
    feedUrl: "https://www.pulsesports.co.ke/rss",
  },
  // --- Blogs / analysts / commentators / referee bodies -------------------------------
  // These voices matter for legislation-implementation and welfare coverage but most
  // don't run a CMS with a reliable feed the way newsrooms do. Add real ones here as you
  // find them (verify the feed URL first, same as any source above); until then this
  // list is intentionally short and honest rather than padded with guessed URLs.
  {
    countryCode: "KE",
    sourceType: "blog",
    name: "Kenyan sports blogs (add feeds as found)",
    feedUrl: null, // placeholder — fill in once you've verified a specific blog's feed
  },
  {
    countryCode: "KE",
    sourceType: "referee",
    name: "Kenya Referees Association (add feed/RSS if published)",
    feedUrl: null, // most federation bodies publish updates as web pages, not RSS —
    // consider a small dedicated scraper for this one page if it never gets a feed
  },
];

// Ordered Kenya-first, then other African countries, then the rest can be added the
// same way. Ticketmaster's Discovery API doesn't have event inventory in every one of
// these countries yet — ingestEvents.js just logs 0 results and moves on when that
// happens, it doesn't fail the run.
const COUNTRIES = [
  { code: "KE", name: "Kenya", flag: "\uD83C\uDDF0\uD83C\uDDEA" },
  { code: "NG", name: "Nigeria", flag: "\uD83C\uDDF3\uD83C\uDDEC" },
  { code: "ZA", name: "South Africa", flag: "\uD83C\uDDFF\uD83C\uDDE6" },
  { code: "GH", name: "Ghana", flag: "\uD83C\uDDEC\uD83C\uDDED" },
  { code: "EG", name: "Egypt", flag: "\uD83C\uDDEA\uD83C\uDDEC" },
  { code: "ET", name: "Ethiopia", flag: "\uD83C\uDDEA\uD83C\uDDF9" },
  { code: "TZ", name: "Tanzania", flag: "\uD83C\uDDF9\uD83C\uDDFF" },
  { code: "UG", name: "Uganda", flag: "\uD83C\uDDFA\uD83C\uDDEC" },
  { code: "MA", name: "Morocco", flag: "\uD83C\uDDF2\uD83C\uDDE6" },
  { code: "SN", name: "Senegal", flag: "\uD83C\uDDF8\uD83C\uDDF3" },
  { code: "CI", name: "Ivory Coast", flag: "\uD83C\uDDE8\uD83C\uDDEE" },
  { code: "CM", name: "Cameroon", flag: "\uD83C\uDDE8\uD83C\uDDF2" },
  // Add more countries here the same way as you expand beyond Africa —
  // { code: "GB", name: "United Kingdom", flag: "🇬🇧" }, etc.
];

// All 47 Kenyan counties, for tagging KE articles by where the story is actually about
// (a county sports ground, a county assembly sports budget line, a county athletics meet,
// etc). classifyArticle() in claude.js matches against this list; "National" covers
// stories about Kenya as a whole rather than one county.
const COUNTIES_KE = [
  "Mombasa", "Kwale", "Kilifi", "Tana River", "Lamu", "Taita Taveta", "Garissa",
  "Wajir", "Mandera", "Marsabit", "Isiolo", "Meru", "Tharaka-Nithi", "Embu",
  "Kitui", "Machakos", "Makueni", "Nyandarua", "Nyeri", "Kirinyaga",
  "Murang'a", "Kiambu", "Turkana", "West Pokot", "Samburu", "Trans Nzoia",
  "Uasin Gishu", "Elgeyo-Marakwet", "Nandi", "Baringo", "Laikipia", "Nakuru",
  "Narok", "Kajiado", "Kericho", "Bomet", "Kakamega", "Vihiga", "Bungoma",
  "Busia", "Siaya", "Kisumu", "Homa Bay", "Migori", "Kisii", "Nyamira",
  "Nairobi",
];

// Categories for the welfare/development tracker (welfare_reports table). Each entry
// stored there is tagged with one of these plus a status of progress / gap / opportunity
// / missed_opportunity — see welfareSearch.js and ingestWelfareReports.js.
const WELFARE_CATEGORIES = [
  "Athlete Welfare & Pay",
  "Facilities & Infrastructure",
  "Grassroots & Talent Development",
  "Sports Legislation & Governance",
  "Anti-Doping & Integrity",
  "Gender Equity in Sport",
  "Referee & Match Official Welfare",
  "Funding & Sponsorship",
];

// Search terms used for YouTube ingestion, per country. Kept generic (name + sport
// keywords) so adding a country to COUNTRIES above is enough for RSS + events; add an
// entry here too if you want more targeted YouTube queries for that country (e.g. a
// specific league or national team name pulls better results than the generic form).
const YOUTUBE_QUERIES_BY_COUNTRY = {
  KE: ["Kenya sports highlights", "Harambee Stars", "Kenya athletics"],
  NG: ["Nigeria sports highlights", "Super Eagles"],
  ZA: ["South Africa sports highlights", "Bafana Bafana", "Springboks"],
  GH: ["Ghana sports highlights", "Black Stars"],
  EG: ["Egypt sports highlights", "Pharaohs football"],
  ET: ["Ethiopia sports highlights", "Ethiopia athletics"],
  TZ: ["Tanzania sports highlights", "Taifa Stars"],
  UG: ["Uganda sports highlights", "Cranes football"],
  MA: ["Morocco sports highlights", "Atlas Lions"],
  SN: ["Senegal sports highlights", "Lions of Teranga"],
  CI: ["Ivory Coast sports highlights", "Elephants football"],
  CM: ["Cameroon sports highlights", "Indomitable Lions"],
};

// Queries with no single-country focus — global tournaments, awards, sponsor news.
const GLOBAL_YOUTUBE_QUERIES = [
  "World Cup highlights",
  "Olympics highlights",
  "Champions League highlights",
  "African Cup of Nations highlights",
  "sports awards ceremony",
];

const SPORTS = [
  "Football",
  "Athletics",
  "Rugby",
  "Volleyball",
  "Basketball",
  "Boxing",
  "Cricket",
  "Motorsport",
  "Golf",
  "Sports Legislation & Governance",
  "Other",
];

// Social platforms this app could pull from, IF you supply your own developer
// credentials. Disabled by default. Facebook, X/Twitter, Instagram, and TikTok all
// prohibit scraping outside their official APIs in their Terms of Service — that's why
// there's no scraper for them here. Get API access, set enabled: true, and implement the
// platform's documented search/timeline call in a new ingestSocial.js that follows the
// same insert-into-articles pattern as ingest.js.
const SOCIAL_SOURCES = {
  twitter_x: { enabled: false, bearerToken: process.env.X_BEARER_TOKEN || "" },
  facebook: { enabled: false, accessToken: process.env.FB_ACCESS_TOKEN || "" },
};

module.exports = {
  SOURCES,
  COUNTRIES,
  COUNTIES_KE,
  WELFARE_CATEGORIES,
  SPORTS,
  SOCIAL_SOURCES,
  YOUTUBE_QUERIES_BY_COUNTRY,
  GLOBAL_YOUTUBE_QUERIES,
};
