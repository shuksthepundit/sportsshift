const express = require("express");
const db = require("../db");
const { WELFARE_CATEGORIES } = require("../sources");

const router = express.Router();

// GET /api/welfare-reports?category=...&status=...&county=...&limit=30
router.get("/welfare-reports", (req, res) => {
  const { category, status, county, country, limit = 30, offset = 0 } = req.query;

  const conditions = [];
  const params = {};

  if (category) {
    conditions.push("category = @category");
    params.category = category;
  }
  if (status) {
    conditions.push("status = @status");
    params.status = status;
  }
  if (county) {
    conditions.push("county_code = @county");
    params.county = county;
  }
  if (country) {
    conditions.push("country_code = @country");
    params.country = country;
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  params.limit = Math.min(Number(limit) || 30, 100);
  params.offset = Number(offset) || 0;

  const rows = db
    .prepare(
      `SELECT id, category, status, title, summary, sport, county_code, country_code,
              source_url, reviewed, ingested_at
       FROM welfare_reports
       ${where}
       ORDER BY ingested_at DESC
       LIMIT @limit OFFSET @offset`
    )
    .all(params);

  res.json({ reports: rows, count: rows.length });
});

// GET /api/welfare-categories — configured categories with counts per status, so the
// frontend can render something like a scorecard grid (category x status).
router.get("/welfare-categories", (_req, res) => {
  const counts = db
    .prepare(
      `SELECT category, status, COUNT(*) as count FROM welfare_reports GROUP BY category, status`
    )
    .all();

  const byCategory = Object.fromEntries(
    WELFARE_CATEGORIES.map((c) => [
      c,
      { progress: 0, gap: 0, opportunity: 0, missed_opportunity: 0 },
    ])
  );
  for (const row of counts) {
    if (byCategory[row.category]) byCategory[row.category][row.status] = row.count;
  }

  res.json(
    WELFARE_CATEGORIES.map((category) => ({ category, counts: byCategory[category] }))
  );
});

module.exports = router;
