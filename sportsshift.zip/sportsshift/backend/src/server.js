require("dotenv").config();
const express = require("express");
const cors = require("cors");
const cron = require("node-cron");
const newsRoutes = require("./routes/news");
const videoRoutes = require("./routes/videos");
const eventRoutes = require("./routes/events");
const liveScoresRoutes = require("./routes/liveScores");
const digestRoutes = require("./routes/digest");
const dailyArticleRoutes = require("./routes/dailyArticle");
const autoArticlesRoutes = require("./routes/autoArticles");
const welfareRoutes = require("./routes/welfare");
const { ingestAll } = require("./ingest");
const { ingestVideos } = require("./ingestVideos");
const { ingestEvents } = require("./ingestEvents");
const { ingestLiveScores } = require("./ingestLiveScores");
const { ingestDailyDigest } = require("./ingestDailyDigest");
const { publishDailyArticle } = require("./ingestDailyArticle");
const { ingestAutoArticles } = require("./ingestAutoArticles");
const { ingestWelfareReports } = require("./ingestWelfareReports");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => res.json({ ok: true }));
app.use("/api", newsRoutes);
app.use("/api", videoRoutes);
app.use("/api", eventRoutes);
app.use("/api", liveScoresRoutes);
app.use("/api", digestRoutes);
app.use("/api", dailyArticleRoutes);
app.use("/api", autoArticlesRoutes);
app.use("/api", welfareRoutes);

async function ingestEverything() {
  const [articles, videos, events] = await Promise.all([
    ingestAll(),
    ingestVideos(),
    ingestEvents(),
  ]);
  return { articles, videos, events };
}

// Manual trigger, useful for a hosting provider's own scheduler (e.g. a Render/Railway
// cron job hitting this endpoint) instead of the in-process one below.
app.post("/api/ingest", async (_req, res) => {
  try {
    const results = await ingestEverything();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Separate manual triggers for the two AI-search-powered pipelines, since they run on
// their own cadences (12h for live scores, 12h for the digest) rather than joining
// the RSS/video/events run above.
app.post("/api/ingest/live-scores", async (_req, res) => {
  try {
    const results = await ingestLiveScores();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/api/ingest/digest", async (_req, res) => {
  try {
    const results = await ingestDailyDigest();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/api/ingest/daily-article", async (_req, res) => {
  try {
    const results = await publishDailyArticle();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/api/ingest/auto-articles", async (_req, res) => {
  try {
    const results = await ingestAutoArticles();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/api/ingest/welfare", async (_req, res) => {
  try {
    const results = await ingestWelfareReports();
    res.json({ ok: true, results });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`API listening on http://localhost:${PORT}`);
});

// Built-in scheduler. Defaults to 1440 minutes (24 hours) per spec — content re-updates
// once a day. Lower this in .env if you want fresher headlines during the day; set to 0
// to disable and trigger POST /api/ingest from an external scheduler instead.
const intervalMinutes = Number(process.env.INGEST_INTERVAL_MINUTES ?? 1440);
if (intervalMinutes > 0) {
  cron.schedule(`*/${intervalMinutes} * * * *`, () => {
    console.log("Running scheduled ingestion...");
    ingestEverything().catch((err) => console.error("Scheduled ingestion failed:", err));
  });
  // Also run once on boot so the app isn't empty on first start.
  ingestEverything().catch((err) => console.error("Initial ingestion failed:", err));
}

// Second, independent cadence for live scores ingestion — every 12 hours. (Previously
// there was also a 15-minute cycle; that's been removed, so this 12-hour run is now
// the only live scores refresh.) Set LIVE_SCORES_INTERVAL_HOURS=0 to disable.
const liveScoresIntervalHours = Number(process.env.LIVE_SCORES_INTERVAL_HOURS ?? 12);
if (liveScoresIntervalHours > 0) {
  cron.schedule(`0 */${liveScoresIntervalHours} * * *`, () => {
    console.log("Running scheduled live scores ingestion (12-hour cycle)...");
    ingestLiveScores().catch((err) => console.error("Scheduled live scores ingestion failed:", err));
  });
  // Run once on boot so the app isn't empty on first start.
  ingestLiveScores().catch((err) => console.error("Initial live scores ingestion failed:", err));
}

// The AI-search daily digest is heavier (a full web-search-augmented Claude call) and
// doesn't need live-score freshness, so it runs on its own slower cadence — every 12
// hours by default. Set DAILY_DIGEST_INTERVAL_HOURS=0 to disable.
const digestIntervalHours = Number(process.env.DAILY_DIGEST_INTERVAL_HOURS ?? 12);
if (digestIntervalHours > 0) {
  cron.schedule(`0 */${digestIntervalHours} * * *`, () => {
    console.log("Running scheduled daily digest ingestion...");
    ingestDailyDigest().catch((err) => console.error("Scheduled daily digest ingestion failed:", err));
  });
  ingestDailyDigest().catch((err) => console.error("Initial daily digest ingestion failed:", err));
}

// Publishes one AI-written roundup article automatically every 24 hours. Re-runs the
// same calendar day just update that day's article in place (see ingestDailyArticle.js)
// rather than creating duplicates. Set DAILY_ARTICLE_INTERVAL_HOURS=0 to disable.
const dailyArticleIntervalHours = Number(process.env.DAILY_ARTICLE_INTERVAL_HOURS ?? 24);
if (dailyArticleIntervalHours > 0) {
  cron.schedule(`0 */${dailyArticleIntervalHours} * * *`, () => {
    console.log("Running scheduled daily article publish...");
    publishDailyArticle().catch((err) => console.error("Scheduled daily article publish failed:", err));
  });
  publishDailyArticle().catch((err) => console.error("Initial daily article publish failed:", err));
}

// Publishes a separate article per new digest headline / new match result (not one
// combined roundup — see AUTO_ARTICLES_MAX_PER_RUN in .env to bound cost per run).
// Every 24 hours by default. Set AUTO_ARTICLES_INTERVAL_HOURS=0 to disable.
const autoArticlesIntervalHours = Number(process.env.AUTO_ARTICLES_INTERVAL_HOURS ?? 24);
if (autoArticlesIntervalHours > 0) {
  cron.schedule(`0 */${autoArticlesIntervalHours} * * *`, () => {
    console.log("Running scheduled auto articles generation...");
    ingestAutoArticles().catch((err) => console.error("Scheduled auto articles generation failed:", err));
  });
  ingestAutoArticles().catch((err) => console.error("Initial auto articles generation failed:", err));
}

// Welfare/development tracker (progress, gaps, opportunities, missed opportunities) —
// every 24 hours by default, matching the rest of the daily-cadence content. Set
// WELFARE_INTERVAL_HOURS=0 to disable.
const welfareIntervalHours = Number(process.env.WELFARE_INTERVAL_HOURS ?? 24);
if (welfareIntervalHours > 0) {
  cron.schedule(`0 */${welfareIntervalHours} * * *`, () => {
    console.log("Running scheduled welfare tracker ingestion...");
    ingestWelfareReports().catch((err) => console.error("Scheduled welfare tracker ingestion failed:", err));
  });
  ingestWelfareReports().catch((err) => console.error("Initial welfare tracker ingestion failed:", err));
}
