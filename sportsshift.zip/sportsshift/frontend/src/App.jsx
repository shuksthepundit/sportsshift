import { useEffect, useState } from "react";
import { fetchNews, fetchCountries, fetchCounties, fetchSports } from "./api";
import Header from "./components/Header.jsx";
import FeatureStrip from "./components/FeatureStrip.jsx";
import CountryTabs from "./components/CountryTabs.jsx";
import SportFilter from "./components/SportFilter.jsx";
import CountyFilter from "./components/CountyFilter.jsx";
import NewsCard from "./components/NewsCard.jsx";
import Sidebar from "./components/Sidebar.jsx";
import DailyArticleBanner from "./components/DailyArticleBanner.jsx";
import AutoArticlesSection from "./components/AutoArticlesSection.jsx";
import WelfareTracker from "./components/WelfareTracker.jsx";

export default function App() {
  const [countries, setCountries] = useState([]);
  const [counties, setCounties] = useState([]);
  const [sports, setSports] = useState([]);
  const [activeCountry, setActiveCountry] = useState("KE");
  const [activeSport, setActiveSport] = useState(null);
  const [activeCounty, setActiveCounty] = useState(null);
  const [articles, setArticles] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ready | error

  useEffect(() => {
    fetchCountries().then(setCountries).catch(() => {});
    fetchCounties().then(setCounties).catch(() => {});
    fetchSports().then(setSports).catch(() => {});
  }, []);

  useEffect(() => {
    setStatus("loading");
    fetchNews({ country: activeCountry, sport: activeSport, county: activeCounty })
      .then((data) => {
        setArticles(data.articles);
        setStatus("ready");
      })
      .catch(() => setStatus("error"));
  }, [activeCountry, activeSport, activeCounty]);

  return (
    <div className="app">
      <Header />
      <FeatureStrip />

      <div className="home-layout">
        <main className="main">
          <DailyArticleBanner />

          {countries.length > 0 && (
            <CountryTabs
              countries={countries}
              activeCountry={activeCountry}
              onSelect={(code) => {
                setActiveCountry(code);
                setActiveSport(null);
                setActiveCounty(null);
              }}
            />
          )}

          {sports.length > 0 && (
            <SportFilter sports={sports} activeSport={activeSport} onSelect={setActiveSport} />
          )}

          {/* Counties only make sense once you're looking at Kenya specifically */}
          {activeCountry === "KE" && counties.length > 0 && (
            <CountyFilter counties={counties} activeCounty={activeCounty} onSelect={setActiveCounty} />
          )}

          {status === "loading" && <p className="status-message">Loading fixtures…</p>}

          {status === "error" && (
            <p className="status-message status-message--error">
              Couldn't reach the news API. Is the backend running on port 4000?
            </p>
          )}

          {status === "ready" && articles.length === 0 && (
            <p className="status-message">
              No stories yet for this filter. Run <code>npm run ingest</code> in the backend to
              pull the latest news.
            </p>
          )}

          {status === "ready" && articles.length > 0 && (
            <div className="news-grid">
              {articles.map((article) => (
                <NewsCard key={article.id} article={article} />
              ))}
            </div>
          )}

          <AutoArticlesSection />

          <WelfareTracker />
        </main>

        <Sidebar />
      </div>
    </div>
  );
}
