const BASE = "/api";

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`Request to ${path} failed: ${res.status}`);
  return res.json();
}

export function fetchNews({ country, sport, county, limit = 30 } = {}) {
  const params = new URLSearchParams();
  if (country) params.set("country", country);
  if (sport) params.set("sport", sport);
  if (county) params.set("county", county);
  params.set("limit", String(limit));
  return get(`/news?${params.toString()}`);
}

export function fetchCountries() {
  return get("/countries");
}

export function fetchCounties() {
  return get("/counties");
}

export function fetchSports() {
  return get("/sports");
}

export function fetchWelfareReports({ category, status, county, country, limit = 30 } = {}) {
  const params = new URLSearchParams();
  if (category) params.set("category", category);
  if (status) params.set("status", status);
  if (county) params.set("county", county);
  if (country) params.set("country", country);
  params.set("limit", String(limit));
  return get(`/welfare-reports?${params.toString()}`);
}

export function fetchWelfareCategories() {
  return get("/welfare-categories");
}

export function fetchLiveScores() {
  return get("/live-scores");
}

export function fetchResults() {
  return get("/results");
}

export function fetchDigest() {
  return get("/digest");
}

export function fetchDailyArticle() {
  return get("/daily-article");
}

export function fetchAutoArticles() {
  return get("/auto-articles");
}
