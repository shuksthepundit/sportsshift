import { useState } from "react";
import { triggerIngest } from "../api";

/**
 * Manual "refresh now" control. The backend already re-ingests automatically every
 * 24 hours (see server.js), so this doesn't replace that — it's for anyone who wants
 * the latest headlines right now instead of waiting for the next scheduled run.
 */
export default function RefreshButton({ onRefreshed }) {
  const [state, setState] = useState("idle"); // idle | loading | done | error

  async function handleClick() {
    setState("loading");
    try {
      const result = await triggerIngest();
      setState("done");
      if (onRefreshed) onRefreshed(result);
      setTimeout(() => setState("idle"), 2500);
    } catch (err) {
      setState("error");
      setTimeout(() => setState("idle"), 3000);
    }
  }

  const label =
    state === "loading"
      ? "Refreshing…"
      : state === "done"
      ? "Updated ✓"
      : state === "error"
      ? "Refresh failed"
      : "⟳ Refresh now";

  return (
    <button
      type="button"
      className={`refresh-button refresh-button--${state}`}
      onClick={handleClick}
      disabled={state === "loading"}
      title="Fetch the latest sports news right now, instead of waiting for the 24-hour auto-refresh"
    >
      {label}
    </button>
  );
}
