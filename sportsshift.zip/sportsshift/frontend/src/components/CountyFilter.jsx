export default function CountyFilter({ counties, activeCounty, onSelect }) {
  return (
    <div className="sport-filter" role="tablist" aria-label="Filter by Kenyan county">
      <button
        className={`sport-pill ${!activeCounty ? "is-active" : ""}`}
        onClick={() => onSelect(null)}
      >
        All Counties
      </button>
      {counties
        .filter((c) => c.articleCount > 0)
        .map((c) => (
          <button
            key={c.code}
            className={`sport-pill ${activeCounty === c.code ? "is-active" : ""}`}
            onClick={() => onSelect(c.code)}
          >
            {c.name}
            <span className="sport-count">{c.articleCount}</span>
          </button>
        ))}
    </div>
  );
}
