import LogoMark from "./LogoMark.jsx";

export default function Header() {
  return (
    <header className="header">
      <div className="header-glow" aria-hidden="true" />
      <div className="header-inner">
        <div className="brand-row">
          <LogoMark size={52} />
          <div className="brand-text">
            <span className="brand-name">SPORTSSHIFT</span>
            <span className="brand-ribbon">Kenya</span>
          </div>
        </div>

        <p className="tagline">
          <span className="tagline-accent">REAL</span> NEWS.{" "}
          <span className="tagline-accent">REAL</span> SPORT.{" "}
          <span className="tagline-accent">REAL</span> WELFARE.
        </p>
      </div>

      <div className="brush-stroke brush-stroke--left" aria-hidden="true" />
      <div className="brush-stroke brush-stroke--right" aria-hidden="true" />
    </header>
  );
}
