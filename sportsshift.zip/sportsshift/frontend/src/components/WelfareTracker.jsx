import { useEffect, useState } from "react";
import { fetchWelfareCategories, fetchWelfareReports } from "../api";

const STATUS_LABEL = {
  progress: "Progress",
  gap: "Gap",
  opportunity: "Opportunity",
  missed_opportunity: "Missed Opportunity",
};

export default function WelfareTracker() {
  const [categories, setCategories] = useState([]);
  const [reports, setReports] = useState([]);
  const [activeStatus, setActiveStatus] = useState(null);
  const [status, setStatus] = useState("loading");

  useEffect(() => {
    fetchWelfareCategories().then(setCategories).catch(() => {});
  }, []);

  useEffect(() => {
    setStatus("loading");
    fetchWelfareReports({ status: activeStatus })
      .then((data) => {
        setReports(data.reports || []);
        setStatus("ready");
      })
      .catch(() => setStatus("error"));
  }, [activeStatus]);

  return (
    <section className="welfare-tracker">
      <div className="welfare-tracker__header">
        <h2 className="sidebar-card__title">Athlete &amp; Sports Welfare Tracker</h2>
        <p className="welfare-tracker__note">
          Tracks development progress, gaps, opportunities, and missed opportunities
          affecting the welfare of sportsmen and women — funding, facilities, legislation
          implementation, anti-doping, gender equity, and referee/official welfare, in
          Kenya and abroad. Items are AI-drafted from web search and marked unreviewed
          until an editor confirms them against the source.
        </p>
      </div>

      {categories.length > 0 && (
        <div className="welfare-scorecard">
          {categories.map((c) => (
            <div key={c.category} className="welfare-scorecard__row">
              <span className="welfare-scorecard__category">{c.category}</span>
              <div className="welfare-scorecard__bars">
                {Object.entries(c.counts).map(([key, value]) => (
                  <span
                    key={key}
                    className={`welfare-badge welfare-badge--${key}`}
                    title={`${STATUS_LABEL[key]}: ${value}`}
                  >
                    {value}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="sport-filter" role="tablist" aria-label="Filter welfare tracker by status">
        <button
          className={`sport-pill ${!activeStatus ? "is-active" : ""}`}
          onClick={() => setActiveStatus(null)}
        >
          All
        </button>
        {Object.entries(STATUS_LABEL).map(([key, label]) => (
          <button
            key={key}
            className={`sport-pill ${activeStatus === key ? "is-active" : ""}`}
            onClick={() => setActiveStatus(key)}
          >
            {label}
          </button>
        ))}
      </div>

      {status === "loading" && <p className="status-message">Loading welfare tracker…</p>}
      {status === "error" && (
        <p className="status-message status-message--error">
          Couldn't load the welfare tracker. Is the backend running?
        </p>
      )}
      {status === "ready" && reports.length === 0 && (
        <p className="status-message">
          No items yet. Run <code>npm run ingest:welfare</code> in the backend, or wait for
          the next scheduled 24-hour refresh.
        </p>
      )}

      {status === "ready" && reports.length > 0 && (
        <ul className="welfare-list">
          {reports.map((r) => (
            <li key={r.id} className="welfare-list__item">
              <div className="welfare-list__meta">
                <span className={`welfare-badge welfare-badge--${r.status}`}>
                  {STATUS_LABEL[r.status]}
                </span>
                <span className="news-card-sport">{r.category}</span>
                {!r.reviewed && <span className="welfare-unreviewed">Unreviewed</span>}
              </div>
              <a className="welfare-list__title" href={r.source_url} target="_blank" rel="noreferrer">
                {r.title}
              </a>
              {r.summary && <p className="welfare-list__summary">{r.summary}</p>}
              <p className="welfare-list__location">
                {r.country_code === "KE" ? r.county_code || "National" : r.country_code}
                {r.sport ? ` · ${r.sport}` : ""}
              </p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
